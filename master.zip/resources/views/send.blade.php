<form action="/post" method="post">
    @csrf
    <input type="text" name="try">
    <input type="submit" value="ok">
</form>