<?php $__env->startSection('title','JENIS OBJEK'); ?>

<?php $__env->startSection('head'); ?>
  
  <link rel="stylesheet" href="<?php echo e(asset('style_admin/table.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('style_admin/form.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('style_admin/action.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('style_admin/alert.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('style_admin/button.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('bs/pagination.css')); ?>">
  <script src="<?php echo e(asset('js_admin/nav.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('copy'); ?>
oncopy='return false' oncut='return false' onpaste='return false'
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrump'); ?>
    Master Jenis
<?php $__env->stopSection(); ?>
<?php $__env->startSection('isi'); ?>
  <div class="isi">
    <a style="color:white;" class="add" href="#add">Tambah</a>
    <table>
      <caption>Tabel Jenis</caption>
      <thead>
        <tr>
          <th scope="col">No</th>
          <th scope="col">Kategori</th>
          <th scope="col">Jenis</th>
          <th scope="col">Icon</th>
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nomor => $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr id="<?php echo e($dt->id); ?>" class="table">
            <td data-label="No"><?php echo e($nomor + $data->firstitem()); ?></td>
            <td data-label="Kategori"><?php echo e($dt->nama); ?></td>
            <td data-label="Jenis"><?php echo e($dt->jenis); ?></td>
            <td data-label="Icon"><img width="50px" height="50px" src="<?php echo e(asset('gambar/jenis/'.$dt->marker.'')); ?>" alt=""></td>
              
              <div id="contextMenu" class="cm_<?php echo e($dt->id); ?>" style="display: none">
                <ul class="dropdown-menu" role="menu" aria-labelledby="dropdownMenu" style="display:block;position:static;margin-bottom:5px;">
                  <li class="edit">
                    <a href="#popup_e<?php echo e($dt->id); ?>">EDIT</a>
                  </li>
                  <?php if($dt->jenis != 'Kerusakan'): ?>
                  <li class="hapus">
                    <a href="#popup_h<?php echo e($dt->id); ?>">HAPUS</a>
                  </li>
                  <?php endif; ?>
                </ul>
              </div>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
    <?php echo e($data->links()); ?>

  </div>
  <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
    <div id="popup_e<?php echo e($dt->id); ?>" class="overlay">
      <div class="popup">
        <h2>Edit Data Jenis</h2>
        <div class="content">
          <form id="form" action="/master_jenis_ubah/<?php echo e($dt->id); ?>" method="post" enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>

            <input type="reset" id="configreset" value="&times;" class="close" onclick="href();">
            <fieldset>
              <input placeholder="Kategori" type="text" autocomplete="off" name="nama" value="<?php echo e($dt->nama ?? old('nama')); ?>" tabindex="2" required oninvalid="this.setCustomValidity('Data tidak boleh kosong')" oninput="setCustomValidity('')">
              <?php if ($errors->has('nama')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nama'); ?>
              <div class="invalid-feedback">
                  <?php echo e($message); ?>

              </div>
              <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </fieldset>
            <fieldset>
              <select name="jenis" id="form" required>
                <option <?php if($dt->jenis=='' || old('jenis')==''): ?> selected <?php endif; ?> value="">-- PILIH --</option>
                <option <?php if($dt->jenis=='Kerusakan' || old('jenis')=='Kerusakan'): ?> selected <?php endif; ?> value="Kerusakan">Objek Kerusakan</option>
                <option <?php if($dt->jenis=='Peta' || old('jenis')=='Peta'): ?> selected <?php endif; ?> value="Peta">Objek Peta</option>
              </select>
              <?php if ($errors->has('jenis')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('jenis'); ?>
              <div class="invalid-feedback">
                  <?php echo e($message); ?>

              </div>
              <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </fieldset>
            <fieldset>
              <input type="file" id="fileimg1" accept="image/*" name="marker">
              <input type="text" name="marker1" hidden value="<?php echo e($dt->marker ?? old('marker1')); ?>">
              <img src="<?php echo e(asset('gambar/jenis/'.$dt->marker)); ?>" alt="">
            </fieldset>
            <fieldset>
              <button name="submit" type="submit" id="contact-submit" data-submit="...Sending">Simpan</button>
            </fieldset>
            <fieldset>
              <a id="cancel" href="/master_jenis">Cancel</a>
            </fieldset>
        </form>
        </div>
      </div>
    </div>
    
    <div id="popup_h<?php echo e($dt->id); ?>" class="overlay">
      <div class="popup">
        <h2>Hapus Data Jenis?</h2>
        <div class="content">
          <fieldset class="acc">
            <a class="acc" href="/master_jenis_hapus/<?php echo e($dt->id); ?>">HAPUS</a>
            <a class="cancel" href="#">BATAL</a>
          </fieldset>
        </div>
      </div>
    </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <div id="add" class="overlay">
    <div class="popup">
      <h2>Form Tambah Data</h2>
      <div class="content">
        <form id="form" action="/master_jenis_tambah" method="post" enctype="multipart/form-data">
          <?php echo e(csrf_field()); ?>

          <input type="reset" id="configreset" value="&times;" class="close" onclick="href();">
          <fieldset>
            <input placeholder="Kategori" type="text" autocomplete="off" name="nama" value="<?php echo e(old('nama')); ?>" tabindex="1" required oninvalid="this.setCustomValidity('Data tidak boleh kosong')" oninput="setCustomValidity('')">
            <?php if ($errors->has('nama')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nama'); ?>
            <div class="invalid-feedback">
                <?php echo e($message); ?>

            </div>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
          </fieldset>
          <fieldset>
            <select name="jenis" id="form" required>
              <option <?php if(old('jenis')==''): ?> selected <?php endif; ?> value="">-- PILIH --</option>
              <option <?php if(old('jenis')=='Kerusakan'): ?> selected <?php endif; ?> value="Kerusakan">Objek Kerusakan</option>
              <option <?php if(old('jenis')=='Peta'): ?> selected <?php endif; ?> value="Peta">Objek Peta</option>
            </select>
            <?php if ($errors->has('jenis')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('jenis'); ?>
            <div class="invalid-feedback">
                <?php echo e($message); ?>

            </div>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
          </fieldset>
          <fieldset>
            <input type="file" id="fileimg" accept="image/*" name="marker" required>
          </fieldset>
          <fieldset>
            <button name="submit" type="submit" id="contact-submit" data-submit="...Sending">Simpan</button>
          </fieldset>
          <fieldset>
            <a id="cancel" href="/master_jenis">Cancel</a>
          </fieldset>
      </form>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
      function href() {
        window.location.href = '#';
      }
    </script>
    <script src="<?php echo e(asset('js_admin/action.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('super.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\TA\projek\program\master\resources\views/super/master/master_jenis.blade.php ENDPATH**/ ?>