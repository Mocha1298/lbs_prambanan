<?php $__env->startSection('head'); ?>
<link rel="stylesheet" href="<?php echo e(asset('style_user/my_suwar.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('style_admin/table.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('style_admin/popup.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('style_admin/form.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title','Profile'); ?>

<?php $__env->startSection('isi'); ?>
<?php $__env->startSection('profile'); ?>
<a class="navoption" href="#edit">Profile</a>
<?php $__env->stopSection(); ?>
<?php if(session('edit')): ?>
<div class="warning"><i class="fa fa-pencil-circle-o fa-2x" aria-hidden="true"></i><?php echo e(session('edit')); ?></div>
<?php endif; ?>
<table>
    <caption>Laporan Saya</caption>
    <thead>
      <tr>
        <th scope="col">No</th>
        <th scope="col">Judul</th>
        <th scope="col">RT/RW</th>
        <th scope="col">Desa</th>
        <th scope="col">Foto</th>
        <th scope="col">Status</th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sw): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr id="<?php echo e($sw->id); ?>" class="table">
          <td data-label="No"><?php echo e($loop->iteration); ?></td>
          <td data-label="Judul"><?php echo e($sw->nama); ?></td>
          <td data-label="RT/RW"><?php echo e($sw->rt); ?>/<?php echo e($sw->rw); ?></td>
          <td data-label="Desa"><?php echo e($sw->nama_desa); ?></td>
          <td data-label="Foto"><a href="/gambar/laporan/ori/<?php echo e($sw->foto1); ?>"><img src="/gambar/laporan/thumbnail/<?php echo e($sw->foto1); ?>" width="100px" height="auto"></a></td>
          <td data-label="Status" style="color:white;background: <?php if($sw->status==1): ?> dodgerblue <?php elseif($sw->status==2): ?> forestgreen <?php else: ?> indianred <?php endif; ?>"><?php if($sw->status==1): ?> Diterima <?php elseif($sw->status==2): ?> Disetujui <?php else: ?> Ditunda <?php endif; ?></td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<div class="pagination">
    <a style="color:white; padding: 10px;" href="/suwar"><i class="fa fa-plus fa-2x"></i></a>
    <?php
      // config
      $link_limit = 10;
      ?>

      <?php if($data->lastPage() > 1): ?>
          <ul style="background: white;">
              <li class="<?php echo e(($data->currentPage() == 1) ? ' disabled' : ''); ?>">
                  <a href="<?php echo e($data->url(1)); ?>">First</a>
              </li>
              <?php for($i = 1; $i <= $data->lastPage(); $i++): ?>
                  <?php
                  $half_total_links = floor($link_limit / 2);
                  $from = $data->currentPage() - $half_total_links;
                  $to = $data->currentPage() + $half_total_links;
                  if ($data->currentPage() < $half_total_links) {
                    $to += $half_total_links - $data->currentPage();
                  }
                  if ($data->lastPage() - $data->currentPage() < $half_total_links) {
                      $from -= $half_total_links - ($data->lastPage() - $data->currentPage()) - 1;
                  }
                  ?>
                  <?php if($from < $i && $i < $to): ?>
                      <li class="<?php echo e(($data->currentPage() == $i) ? ' active' : ''); ?>">
                          <a href="<?php echo e($data->url($i)); ?>"><?php echo e($i); ?></a>
                      </li>
                  <?php endif; ?>
              <?php endfor; ?>
              <li class="<?php echo e(($data->currentPage() == $data->lastPage()) ? ' disabled' : ''); ?>">
                  <a href="<?php echo e($data->url($data->lastPage())); ?>">Last</a>
              </li>
          </ul>
      <?php endif; ?>
</div>
  
  <div id="edit" class="overlay">
    <div class="popup">
      <h2>Form Ubah Data Pengguna</h2>
      <div class="content">
        <form id="form" action="/u_display/<?php echo e(Auth::user()->id); ?>" method="post" enctype="multipart/form-data">
          <?php echo e(csrf_field()); ?>

          <input type="reset" id="configreset" value="&times;" class="close" onclick="href();">
          <fieldset>
              <label for="">Ubah Nama</label>
              <input placeholder="Nama" type="text" autocomplete="off" name="nama" value="<?php echo e(Auth::user()->nama ?? old('nama')); ?>" tabindex="1" required oninvalid="this.setCustomValidity('Data tidak boleh kosong')" oninput="setCustomValidity('')" autofocus>
              <?php if ($errors->has('nama')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nama'); ?>
              <div class="invalid-feedback">
                  <?php echo e($message); ?>

              </div>
              <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?> 
          </fieldset>
          <fieldset>
              <label for="">Ubah Email</label>
              <input placeholder="Email" type="text" autocomplete="off" name="email" value="<?php echo e(Auth::user()->email ?? old('email')); ?>" tabindex="1" required oninvalid="this.setCustomValidity('Data tidak boleh kosong')" oninput="setCustomValidity('')" autofocus>
              <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
              <div class="invalid-feedback">
                  <?php echo e($message); ?>

              </div>
              <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?> 
          </fieldset>
          <fieldset>
              <label for="">Ubah Foto Profile</label>
              <input type="file" id="fileimg1" accept="image/*" name="photo">
              <img style="margin-left: 20px" width="100px" height="auto" src="/gambar/user/<?php echo e(Auth::user()->photo); ?>">
              <?php if ($errors->has('photo')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('photo'); ?>
              <div class="invalid-feedback">
                  <?php echo e($message); ?>

              </div>
              <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
          </fieldset>
          <fieldset>
            <button name="submit" type="submit" id="contact-submit" data-submit="...Sending">Simpan</button>
          </fieldset>
        </form> 
        <form id="form" action="/u_password/<?php echo e(Auth::user()->id); ?>" method="post">
          <label for="">Perbarui Password</label>
          <fieldset>
            <input placeholder="Password Baru" autocomplete="off" type="password" name="password" value="<?php echo e(old('password')); ?>" tabindex="2" required oninvalid="this.setCustomValidity('Data tidak boleh kosong')" oninput="setCustomValidity('')">
            <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
            <div class="invalid-feedback">
                <?php echo e($message); ?>

            </div>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            <input placeholder="Konfirmasi Password Baru" type="email" name="email" value="<?php echo e(old('email')); ?>" tabindex="2" required oninvalid="this.setCustomValidity('Data tidak boleh kosong')" oninput="setCustomValidity('')">
            <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
            <div class="invalid-feedback">
                <?php echo e($message); ?>

            </div>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
          </fieldset>         
          <fieldset>
            <button name="submit" type="submit" id="contact-submit" data-submit="...Sending">Simpan</button>
          </fieldset>
        </form>
      </div>
    </div>
  </div>
  <script>
    function href() {
      window.location.href = '#';
    }
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.lay', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\TA\projek\program\master\resources\views/user/my_suwar.blade.php ENDPATH**/ ?>