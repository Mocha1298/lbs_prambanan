<?php $__env->startSection('head'); ?>
<link rel="stylesheet" href="<?php echo e(asset('style_user/entry.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('bs/pagination.css')); ?>">
<style>
    .blog-author h3::before,
    .blog-author--no-cover h3::before {
        background-size: 60px;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title','LAPORAN SUARA WARGA'); ?>
<?php $__env->startSection('active','active'); ?>

<?php $__env->startSection('isi'); ?>
<?php if(Auth::check()): ?>
  <?php $__env->startSection('profile'); ?>
  <a title="ke halaman profil" class="navoption" href="/my_suwar/<?php echo e(Auth::user()->id); ?>">Profile</a>
  <?php $__env->stopSection(); ?>
<?php endif; ?>
<div class="add-data">
  <h2><a title="ke halaman tambah laporan" href="/suwar">TAMBAH LAPORAN <i class="fa fa-plus"></i></a></h2>
</div>
    <?php $__currentLoopData = $laporan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sw): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="blog-container">
  
            <div class="blog-header">
              <div style="background: url("/gambar/user/<?php echo e($sw->photo); ?>");" class="blog-author--no-cover">
                  <h3><?php echo e($sw->pengirim); ?></h3>
              </div>
            </div>
          
            <div class="blog-body">
              <div class="blog-title">
                <h1><a href="#">Judul : <?php echo e($sw->nama); ?></a></h1>
                <a href="/gambar/laporan/ori/<?php echo e($sw->foto1); ?>"><img src="/gambar/laporan/thumbnail/<?php echo e($sw->foto1); ?>" alt=""></a>
              </div>
              <div class="blog-summary">
                <p>Keterangan : <?php echo e($sw->keterangan); ?>.</p>
              </div>
            </div>

            <?php if($sw->status == 2): ?>
            <div class="blog-body">
              <div class="blog-title">
                <h1><a href="#">Survey</a></h1>
                <a href="/gambar/survey/ori/<?php echo e($sw->foto); ?>"><img style="margin-bottom: 10px" src="/gambar/survey/thumbnail/<?php echo e($sw->foto); ?>" alt="" width="100px" height="auto"></a>
              </div>
            </div>
            <?php endif; ?>
            
            <div class="blog-footer">
              <ul>
                <li class="published-date"><?php echo e($sw->created_at->diffForHumans()); ?></li>
                <li>
                <?php if($sw->status == 1): ?>
                  DITERIMA
                <?php elseif($sw->status == 2): ?>
                  DISURVEY
                <?php elseif($sw->status == 3): ?>
                  VALID
                <?php endif; ?>
                </li>
              </ul>
            </div>
          
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <style>
      .jos{
        width: 100%;
        text-align: center;
      }
    </style>
    <div class="jos">
      <?php echo e($laporan->links()); ?>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.lay', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\TA\projek\program\master\resources\views/user/laporan.blade.php ENDPATH**/ ?>