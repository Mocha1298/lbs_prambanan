<?php $__env->startSection('title','LAPORAN'); ?>

<?php $__env->startSection('head'); ?>
  <link rel="stylesheet" href="<?php echo e(asset('style_admin/table.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('style_admin/action.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('style_admin/button.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('style_admin/popup.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('style_user/box-map.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('bs/pagination.css')); ?>">
  <style>
    #mapid{
      width: 100%;
      height: 500px;
    }
  </style>
  <script src="<?php echo e(asset('jquery/jquery.js')); ?>"></script>
  <script src="<?php echo e(asset('js_admin/nav.js')); ?>"></script>
  <link rel="stylesheet" href="https://unpkg.com/leaflet@1.6.0/dist/leaflet.css"
  integrity="sha512-xwE/Az9zrjBIphAcBb3F6JVqxf46+CDLwfLMHloNu6KEQCAWi6HcDUbeOfBIptF7tcCzusKFjFw2yuvEpDL9wQ=="
  crossorigin=""/>
  <script src="https://unpkg.com/leaflet@1.6.0/dist/leaflet.js"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('copy'); ?>
oncopy='return false' oncut='return false' onpaste='return false'
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrump'); ?>
    <?php if(Auth::user()->roles_id != 2): ?>
        <a href="/master_kecamatan">Master Kecamatan</a> > <a href="/master_desa_back/<?php echo e($id); ?>">Master Kerusakan</a> >Data Kerusakan
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('isi'); ?>
  <div class="isi">
    <a style="right: 0; width: 50px;" href="#map"><i style="width: 28px; height: 28px; color: mediumseagreen;" class="fa fa-globe fa-2x"></i></a>
    <table>
      <caption>Tabel Laporan</caption>
      <thead>
        <tr>
          <th scope="col">No</th>
          <th scope="col">Judul</th>
          <th scope="col">RT/RW</th>
          <th scope="col">Foto</th>
          <th scope="col">Tanggal Masuk</th>
          <th scope="col">Status</th>
        </tr>
      </thead>
      <?php if($count != 0): ?>
        <tbody>
          <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nomor => $sw): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr id="<?php echo e($sw->id); ?>" class="table">
              <td data-label="No"><?php echo e($nomor + $data->firstitem()); ?></td>
              <td data-label="Judul"><?php echo e($sw->nama); ?></td>
              <td data-label="RT/RW"><?php echo e($sw->rt); ?>/<?php echo e($sw->rw); ?></td>
              <td data-label="Foto"><a href="/gambar/laporan/ori/<?php echo e($sw->foto1); ?>"><img src="/gambar/laporan/thumbnail/<?php echo e($sw->foto1); ?>" width="100px" height="auto"></a></td>
              <td data-label="Tanggal Masuk"><?php echo e($sw->created_at); ?></td>
              <td data-label="Status" style="color:white;background: 
              <?php if($sw->status==1): ?>
              dodgerblue
              <?php elseif($sw->status==2): ?>
              forestgreen
              <?php elseif($sw->status==3): ?>
              goldenrod
              <?php else: ?>
              indianred
              <?php endif; ?>
              ">
              <?php if($sw->status==1): ?>
              Diterima
              <?php elseif($sw->status==2): ?>
              Disetujui
              <?php elseif($sw->status==3): ?>
              VALID
              <?php else: ?>
              Ditunda
              <?php endif; ?>
              </td>
              
              <?php if($sw->status == 1): ?>
              <div id="contextMenu" class="cm_<?php echo e($sw->id); ?>" style="display: none">
                <ul class="dropdown-menu" role="menu" aria-labelledby="dropdownMenu" style="display:block;position:static;margin-bottom:5px;">
                  <li class="detail">
                  <a href="/suwar_acc/<?php echo e($sw->id); ?>">SETUJU</a>
                  </li>
                  <li class="hapus">
                    <a href="/suwar_dis/<?php echo e($sw->id); ?>" >DITUNDA</a>
                  </li>
                </ul>
              </div>
              <?php endif; ?>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      <?php else: ?>
        <tbody>
          <tr>Data masih kosong!</tr>
        </tbody>
      <?php endif; ?>
    </table>
    <?php echo e($data->links()); ?>

  </div>
  
  <div id="map" class="overlay">
    <div class="popup">
      <h2>Peta Laporan</h2>
      <a href='#' class='close'>&times;</a>
      <div class="content">
        <div id="mapid"></div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('js_admin/action.js')); ?>"></script>
    <script src="<?php echo e(asset('js_admin/bundle.js')); ?>"></script>
    <script src="<?php echo e(asset('js_admin/ajax.js')); ?>"></script>
    <script>
      $.getJSON("/center_desa", function (data){
          mymap = L.map('mapid',{
              center :  [data.lintang,data.bujur],
              watch : true,
              zoom: 16,
              // scrollWheelZoom: false,
              closePopupOnClick: false
          });
          var geojsonLayer = new L.GeoJSON.AJAX("/batas/"+data.batas,{
              fillOpacity : 0,
              color : 'white'
          });       
          geojsonLayer.addTo(mymap);
          L.tileLayer('http://{s}.google.com/vt/lyrs=s&x={x}&y={y}&z={z}',{
              minZoom: 10,
              maxZoom: 20,
              subdomains:['mt0','mt1','mt2','mt3']
          }).addTo(mymap);
      });
      $.getJSON("/datapeta_desa", function (data1) {
          for (var i = 0; i < data1.length; i++) {
              var name = data1[i].nama;
              L.marker([data1[i].lintang, data1[i].bujur])
              .addTo(mymap)
              .bindPopup(
                  (info =
                      "<div class='cont'>"
                          +"<div class='box'>"
                              +"<div class='header'>"
                                  +"<h2><strong> Nama Laporan : "+name+"</strong></h2>"
                                  +"<p> Keterangan : "+data1[i].keterangan+"</p>"
                                  +"<p>RT/RW : "+data1[i].rt+"/"+data1[i].rw+" </p>"
                              +"</div>"
                              +"<img src='/gambar/laporan/thumbnail/"+data1[i].foto1+"' alt=''>"
                          +"</div>"
                      +"</div>"
                      )
              );
          }
      })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('super.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\TA\projek\program\master\resources\views/super/suwar/laporan.blade.php ENDPATH**/ ?>