<?php $__env->startSection('title','Dashboard'); ?>

<?php $__env->startSection('head'); ?>
<link rel="stylesheet" href="<?php echo e(asset('style_admin/alert.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('style_admin/card.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrump'); ?>
    Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('isi'); ?>
<ul class="card-container">
  <?php if(Auth::user()->roles_id == 1): ?>
    <li class="card user">
      <div class="logo">
        <i class="fa fa-user fa-3x"></i>
      </div>
      <div class="title">
        <div class="name">PENGGUNA</div>
        <div class="number"><?php echo e($data1); ?></div>
      </div>
      <a href="/master_user">
        <div class="detail">
          <i class="fa fa-arrow-right fa-3x"></i>
        </div>
      </a>
    </li>
    <li class="card kecamatan">
      <div class="logo">
        <i class="fa fa-users fa-3x"></i>
      </div>
      <div class="title">
        <div class="name">KECAMATAN</div>
        <div class="number"><?php echo e($data2); ?></div>
      </div>
      <a href="/master_kecamatan">
        <div class="detail">
          <i class="fa fa-arrow-right fa-3x"></i>
        </div>
      </a>
    </li>   
    <li class="card objek">
      <div class="logo">
        <i class="fa fa-tree fa-3x"></i>
      </div>
      <div class="title">
        <div class="name">OBJEK</div>
        <div class="number"><?php echo e($data5); ?></div>
      </div>
      <a href="/objek_peta">
        <div class="detail">
          <i class="fa fa-arrow-right fa-3x"></i>
        </div>
      </a>
    </li>
    <?php else: ?>
    <li class="card kerusakan">
      <div class="logo">
        <i class="fa fa-map fa-3x"></i>
      </div>
      <div class="title">
        <div class="name">KERUSAKAN</div>
        <div class="number"><?php echo e($data3); ?></div>
      </div>
      <a href="/objek_kerusakan">
        <div class="detail">
          <i class="fa fa-arrow-right fa-3x"></i>
        </div>
      </a>
    </li>
    <li class="card laporan">
      <div class="logo">
        <i class="fa fa-file fa-3x"></i>
      </div>
      <div class="title">
        <div class="name">LAPORAN</div>
        <div class="number"><?php echo e($data4); ?></div>
      </div>
      <a href="/suwar_admin/<?php echo e(Auth::user()->villages_id); ?>">
        <div class="detail">
          <i class="fa fa-arrow-right fa-3x"></i>
        </div>
      </a>
    </li>
    <?php endif; ?>
</ul>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('super.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\TA\projek\program\master\resources\views/super/dashboard.blade.php ENDPATH**/ ?>