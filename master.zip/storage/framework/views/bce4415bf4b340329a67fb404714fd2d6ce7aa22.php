<?php $__env->startSection('title','LAPORAN'); ?>

<?php $__env->startSection('head'); ?>
  <link rel="stylesheet" href="<?php echo e(asset('style_admin/table.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('style_admin/form.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('style_admin/popup.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('bs/pagination.css')); ?>">
  <script src="<?php echo e(asset('jquery/jquery.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('copy'); ?>
oncopy='return false' oncut='return false' onpaste='return false'
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrump'); ?>
    Laporan
<?php $__env->stopSection(); ?>
<?php $__env->startSection('isi'); ?>
<div class="isi">
  <style>
    .filter button{
      padding:0 20px;
    }
  </style>
  <a class="filter" href="#filter"><button><i class="fa fa-filter fa-2x"></i></button></a>
    <table>
      <caption>Tabel Laporan</caption>
      <thead>
        <tr>
          <th scope="col">No</th>
          <th scope="col">Judul</th>
          <th scope="col">Pengirim</th>
          <th scope="col">Desa</th>
          <th scope="col">Status</th>
          <th scope="col">Masuk</th>
          <th scope="col">Setuju</th>
          <th scope="col">Valid</th>
        </tr>
      </thead>
      <tbody>
          <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nomor => $lap): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="table">
              <td data-label="No"><?php echo e($nomor + $data->firstitem()); ?></td>
                <td data-label="Judul"><?php echo e($lap->nama); ?></td>
                <td data-label="Pengirim"><?php echo e($lap->sender); ?></td>
                <td data-label="Desa"><?php echo e($lap->desa); ?></td>
                <td data-label="Status">
                  <?php if($lap->status == 1): ?>
                  Diterima
                  <?php elseif($lap->status == 2): ?>
                  Disetujui
                  <?php else: ?>
                  Valid
                  <?php endif; ?>
                </td>
                <td data-label="Masuk"><?php echo e(date('d F Y', strtotime($lap->created_at))); ?></td>
                <td data-label="Setuju"><?php echo e(date('d F Y', strtotime($lap->setuju))); ?></td>
                <td data-label="Valid"><?php echo e(date('d F Y', strtotime($lap->valid))); ?></td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
    </table>
    <?php echo e($data->links()); ?>

    <style>
      .cetak button{
        padding:0 20px;
      }
    </style>
</div>

<div id="filter" class="overlay">
  <div class="popup">
    <h2>Filter</h2>
    <a class="close" href="#">&times;</a>
    <div class="content">
      <div class="filter">
        <form id="form" action="/report/period" method="get">
          <fieldset>
            <select name="filter" id="">
              <option value="texts.created_at">Tanggal Masuk</option>
              <option value="agendas.created_at">Tanggal Acc</option>
              <option value="maps.created_at">Tanggal Valid</option>
            </select>
          </fieldset>
          <fieldset>
            <label for="dari">Dari Tanggal</label>
            <input id="dari" oninput="setmin();" max="<?php echo e(date('Y-m-d')); ?>" name="dari" type="date" value="<?php echo e(date('Y-m-d')); ?>">
          </fieldset>
          <fieldset>
            <label for="sampai">Sampai Tanggal</label>
            <input id="sampai" oninput="setmax();" name="sampai" min="<?php echo e(date('Y-m-d')); ?>" type="date" value="<?php echo e(date('Y-m-d')); ?>">
          </fieldset>
          <button type="submit" name="submit" value="print"><i class="fa fa-print fa-2x"></i></button>
        </form>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
      function setmin() {
        var value = $("#dari")[0].value;
        $("#sampai")[0].min = value;
        // console.log($("#sampai")[0].min);
      }
      function setmax() {
        var value = $("#sampai")[0].value;
        $("#dari")[0].max = value;
        // console.log($("#dari")[0].max);
      }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('super.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\TA\projek\program\master\resources\views/super/report/report.blade.php ENDPATH**/ ?>