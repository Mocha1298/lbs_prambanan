<?php $__env->startSection('title','DESA'); ?>

<?php $__env->startSection('head'); ?>
  <link rel="stylesheet" href="<?php echo e(asset('style_admin/table.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('style_admin/form.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('style_admin/action.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('style_admin/alert.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('style_admin/button.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('bs/pagination.css')); ?>">
  <script src="<?php echo e(asset('js_admin/nav.js')); ?>"></script>
  <script src="<?php echo e(asset('jquery/jquery.js')); ?>"></script>
  <script>
    var x=0;
    var id = [];
    var bujur = [];
    var lintang = [];
    var batas = [];
  </script>
  <style>
    input[type=file]#json::before{
      content: 'Pilih File :';
    }
  </style>
  <link rel="stylesheet" href="https://unpkg.com/leaflet@1.6.0/dist/leaflet.css"
  integrity="sha512-xwE/Az9zrjBIphAcBb3F6JVqxf46+CDLwfLMHloNu6KEQCAWi6HcDUbeOfBIptF7tcCzusKFjFw2yuvEpDL9wQ=="
  crossorigin=""/>
  <script src="<?php echo e(asset('js_admin/leaflet.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('copy'); ?>
oncopy='return false' oncut='return false' onpaste='return false'
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrump'); ?>
    <a href="/master_kecamatan"><?php echo e($kc->nama); ?></a>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('isi'); ?>
  <div class="isi">
    <?php if($admin == 1): ?>
    <a class="add false" href="#">Tambah</a>
    <?php else: ?>
    <a style="color:white;" class="add" href="#add">Tambah</a>
    <?php endif; ?>
    <table>
      <caption>Tabel Desa</caption>
      <thead>
        <tr>
          <th scope="col">No</th>
          <th scope="col">Nama Desa</th>
          <th scope="col">Jumlah RW</th>
        </tr>
      </thead>
      <?php if($count != 0): ?>
        <tbody>
          <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nomor => $ds): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr id="<?php echo e($ds->id); ?>" class="table">
              <td data-label="No"><?php echo e($nomor + $data->firstitem()); ?></td>
              <td data-label="Nama Desa"><?php echo e($ds->nama); ?></td>
              <td data-label="Jumlah RW"><?php echo e($ds->rw); ?></td>
                
                <div id="contextMenu" class="cm_<?php echo e($ds->id); ?>" style="display: none">
                  <ul class="dropdown-menu" role="menu" aria-labelledby="dropdownMenu" style="display:block;position:static;margin-bottom:5px;">
                    <li class="edit">
                      <a href="#popup_e<?php echo e($ds->id); ?>">EDIT</a>
                    </li>
                    <li class="hapus">
                      <a href="#popup_h<?php echo e($ds->id); ?>">HAPUS</a>
                    </li>
                    <li class="detail">
                      <a href="/objek_kerusakan/<?php echo e($ds->id); ?>">KERUSAKAN</a>
                    </li>
                  </ul>
                </div>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      <?php else: ?>
        <tbody>
          <tr>Data masih kosong! tambah sekarang...</tr>
        </tbody>
      <?php endif; ?>
    </table>
    <?php echo e($data->links()); ?>

    </div>
  </div>
  <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ds): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
    <div id="popup_e<?php echo e($ds->id); ?>" class="overlay">
      <div class="popup">
        <h2>Edit Data</h2>
        <div class="content">
          <form id="form" action="/master_desa_ubah/<?php echo e($ds->id); ?>" method="post" enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>

            <input type="reset" id="configreset" value="&times;" class="close" onclick="href();">
            <input type="text" name="id" value="<?php echo e($id); ?>" hidden>
            <fieldset>
              <input placeholder="Nama Desa" type="text" name="nama" value="<?php echo e(old('nama') ?? $ds->nama); ?>" tabindex="1" required oninvalid="this.setCustomValidity('Data tidak boleh kosong')" oninput="setCustomValidity('')" autofocus>
              <?php if ($errors->has('nama')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nama'); ?>
              <div class="invalid-feedback">
                  <?php echo e($message); ?>

              </div>
              <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </fieldset>
            <fieldset>
              <input placeholder="Jumlah RW" type="text" name="rw" value="<?php echo e(old('rw') ?? $ds->rw); ?>" tabindex="2" required oninvalid="this.setCustomValidity('Data tidak boleh kosong')" oninput="setCustomValidity('')">
              <?php if ($errors->has('rw')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('rw'); ?>
              <div class="invalid-feedback">
                  <?php echo e($message); ?>

              </div>
              <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </fieldset>
            <fieldset>
              <input id="json" type="file" autocomplete="off" name="batas" tabindex="3" oninvalid="this.setCustomValidity('Data tidak boleh kosong')" oninput="setCustomValidity('')">
              <p><?php echo e($ds->batas); ?></p>
              <?php if ($errors->has('batas')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('batas'); ?>
              <div class="invalid-feedback">
                  <?php echo e($message); ?>

              </div>
              <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </fieldset>
            <fieldset>
              <input id="bujur<?php echo e($ds->id); ?>" placeholder="Longitude" type="text" name="bujur" value="<?php echo e(old('bujur') ?? $ds->bujur); ?>" required oninvalid="this.setCustomValidity('Data tidak boleh kosong')" oninput="setCustomValidity('')" readonly>
              <?php if ($errors->has('bujur')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('bujur'); ?>
              <div class="invalid-feedback">
                  <?php echo e($message); ?>

              </div>
              <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </fieldset>
            <fieldset>
              <input id="lintang<?php echo e($ds->id); ?>" placeholder="Latitude" type="text" name="lintang" value="<?php echo e(old('lintang') ?? $ds->lintang); ?>" required oninvalid="this.setCustomValidity('Data tidak boleh kosong')" oninput="setCustomValidity('')" readonly>
              <?php if ($errors->has('lintang')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('lintang'); ?>
              <div class="invalid-feedback">
                  <?php echo e($message); ?>

              </div>
              <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </fieldset>
            <fieldset>
            <div onmousemove="getcenter2(<?php echo e($ds->id); ?>);" class="map" id="mapid<?php echo e($ds->id); ?>" style="width: 100%; height: 40vh;">
                <img class="marker" src="<?php echo e(asset('gambar/marker/marker.png')); ?>" alt="">
              </div>
            <fieldset>
            <fieldset>
              <button name="submit" type="submit" id="contact-submit" data-submit="...Sending">Simpan</button>
            </fieldset>
            <fieldset>
              <a id="cancel" href="/master_desa/<?php echo e($id); ?>">Cancel</a>
            </fieldset>
        </form>
        </div>
      </div>
    </div>
    
    <div id="popup_h<?php echo e($ds->id); ?>" class="overlay">
      <div class="popup">
        <h2>Hapus Data?</h2>
        <div class="content">
          <fieldset class="acc">
            <a class="acc" href="/master_desa_hapus/<?php echo e($ds->id); ?>">HAPUS</a>
            <a class="cancel" href="#">Batal</a>
          </fieldset>
        </div>
      </div>
    </div>
    <script>
      id[x] = <?php echo e($ds->id); ?>;
      bujur[x] = <?php echo e($ds->bujur); ?>;
      lintang[x] = <?php echo e($ds->lintang); ?>;
      batas[x] = "<?php echo e($ds->batas); ?>";
      x++;
    </script>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <div id="add" class="overlay">
    <div class="popup">
      <h2>Form Tambah Data</h2>
      <div class="content">
        <form id="form" action="/master_desa_tambah/<?php echo e($id); ?>" method="post" enctype="multipart/form-data">
          <?php echo e(csrf_field()); ?>

          <input type="reset" id="configreset" value="&times;" class="close" onclick="href();">
          <fieldset>
            <input placeholder="Nama Desa" type="text" autocomplete="off" name="nama" value="<?php echo e(old('nama')); ?>" tabindex="1" required oninvalid="this.setCustomValidity('Data tidak boleh kosong')" oninput="setCustomValidity('')" autofocus>
            <?php if ($errors->has('nama')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nama'); ?>
            <div class="invalid-feedback">
                <?php echo e($message); ?>

            </div>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
          </fieldset>
          <fieldset>
            <input placeholder="Jumlah RW" type="text" autocomplete="off" name="rw" value="<?php echo e(old('rw')); ?>" tabindex="2" required oninvalid="this.setCustomValidity('Data tidak boleh kosong')" oninput="setCustomValidity('')">
            <?php if ($errors->has('rw')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('rw'); ?>
            <div class="invalid-feedback">
                <?php echo e($message); ?>

            </div>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
          </fieldset>
          <fieldset>
            <input id="json" placeholder="Batas Desa (.json)" type="file" autocomplete="off" name="batas" value="<?php echo e(old('batas')); ?>" tabindex="3" required oninvalid="this.setCustomValidity('Data tidak boleh kosong')" oninput="setCustomValidity('')">
            <?php if ($errors->has('batas')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('batas'); ?>
            <div class="invalid-feedback">
                <?php echo e($message); ?>

            </div>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
          </fieldset>
          <fieldset>
            <input id="bujur" placeholder="Longitude" type="text" name="bujur" value="<?php echo e(old('bujur')); ?>" required oninvalid="this.setCustomValidity('Data tidak boleh kosong')" oninput="setCustomValidity('')" readonly>
            <?php if ($errors->has('bujur')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('bujur'); ?>
            <div class="invalid-feedback">
                <?php echo e($message); ?>

            </div>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
          </fieldset>
          <fieldset>
            <input id="lintang" placeholder="Latitude" type="text" name="lintang" value="<?php echo e(old('lintang')); ?>" required oninvalid="this.setCustomValidity('Data tidak boleh kosong')" oninput="setCustomValidity('')" readonly>
            <?php if ($errors->has('lintang')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('lintang'); ?>
            <div class="invalid-feedback">
                <?php echo e($message); ?>

            </div>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
          </fieldset>
          <fieldset>
            <div onmousemove="getcenter1();" id="mapid" style="width: 100%; height: 35vh;">
              <img class="marker" src="<?php echo e(asset('gambar/marker/marker.png')); ?>" alt="">
            </div>
          </fieldset>
          <fieldset>
            <button name="submit" type="submit" id="contact-submit" data-submit="...Sending">Simpan</button>
          </fieldset>
          <fieldset>
            <a id="cancel" href="/master_desa">Cancel</a>
          </fieldset>
      </form>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
      function href() {
        window.location.href = '#';
      }
    </script>
    <script>
      var input = "desa";
      var desa = <?php echo e($id); ?>;
    </script>
    <script src="<?php echo e(asset('js_admin/action.js')); ?>"></script>
    <script src="<?php echo e(asset('js_admin/ajax.js')); ?>"></script>
    
    <script>
      var mymap = [];
      $.getJSON("/center/kecamatan/"+desa, function (data0){
          mymap1 = L.map('mapid',{
              center :  [data0.lintang,data0.bujur],
              zoom: 13,
          });
          var geojsonLayer = new L.GeoJSON.AJAX("/batas/"+data0.batas,{
              fillOpacity : 0,
              color : 'white'
          });    
          geojsonLayer.addTo(mymap1);
          L.tileLayer('http://{s}.google.com/vt/lyrs=s,h&x={x}&y={y}&z={z}',{
              maxZoom: 20,
              minZoom: 13,
              subdomains:['mt0','mt1','mt2','mt3']
          }).addTo(mymap1);
      });
      // EDIT
      var sid
      var sbujur
      var slintang
      var sbatas;
      console.log(id[2]);
      console.log("Mulai");
      for (var i = 0; i < id.length; i++) {
          sid = id[i];
          sbujur = bujur[i];
          slintang = lintang[i];
          sbatas = batas[i];
          mymap[sid] = L.map("mapid"+sid, {
              center: [slintang,sbujur],
              zoom: 20,
              // scrollWheelZoom: false,
          });
          var geojsonLayer = new L.GeoJSON.AJAX("/batas/"+sbatas,{
              fillOpacity : 0,
              color : 'white'
          });
          geojsonLayer.addTo(mymap[sid]);
          L.tileLayer('http://{s}.google.com/vt/lyrs=s,h&x={x}&y={y}&z={z}',{
              maxZoom: 20,
              minZoom: 13,
              subdomains:['mt0','mt1','mt2','mt3']
          }).addTo(mymap[sid]);
          
          // Marker Current
          var current = L.icon({
              iconUrl: '/gambar/marker/current.png',
              iconSize:     [17, 17], // size of the icon
              iconAnchor:   [5, 15], // point of the icon which will correspond to marker's location
              popupAnchor:  [-10, -5], // point from which the popup should open relative to the iconAnchor
              tooltipAnchor: [9,-20], //Alhamdulillah nemu bind tool up e aku :D
          });
          L.marker([slintang,sbujur],{icon:current})
          .addTo(mymap[sid])
          .bindPopup("Lokasi terkini");        
      }

      function getcenter1(){
          var center = mymap1.getCenter();
          
          document.getElementById("bujur").value = center.lng;
          document.getElementById("lintang").value = center.lat;
      }

      // EDIT DATA

      function getcenter2(id){
          var center = mymap[id].getCenter();   
          document.getElementById("bujur"+id).value = center.lng;
          document.getElementById("lintang"+id).value = center.lat;
      }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('super.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\TA\projek\program\master\resources\views/super/master/master_desa.blade.php ENDPATH**/ ?>