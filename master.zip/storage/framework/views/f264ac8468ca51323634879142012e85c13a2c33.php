<?php $__env->startSection('title','PROFILE'); ?>

<?php $__env->startSection('head'); ?>
<link rel="stylesheet" href="<?php echo e(asset('style_admin/alert.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('style_admin/form.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrump'); ?>
    PROFILE
<?php $__env->stopSection(); ?>

<?php $__env->startSection('isi'); ?>
<form id="form" action="/display/<?php echo e(Auth::user()->id); ?>" method="post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <fieldset>
        <label for="">Ubah Nama</label>
        <input placeholder="Nama" type="text" autocomplete="off" name="nama" value="<?php echo e(Auth::user()->nama ?? old('nama')); ?>" tabindex="1" required oninvalid="this.setCustomValidity('Data tidak boleh kosong')" oninput="setCustomValidity('')" autofocus>
        <?php if ($errors->has('nama')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nama'); ?>
        <div class="invalid-feedback">
            <?php echo e($message); ?>

        </div>
        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?> 
    </fieldset>
    <fieldset>
        <label for="">Ubah Email</label>
        <input placeholder="Email" type="text" autocomplete="off" name="email" value="<?php echo e(Auth::user()->email ?? old('email')); ?>" tabindex="1" required oninvalid="this.setCustomValidity('Data tidak boleh kosong')" oninput="setCustomValidity('')" autofocus>
        <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
        <div class="invalid-feedback">
            <?php echo e($message); ?>

        </div>
        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?> 
    </fieldset>
    <fieldset>
        <label for="">Ubah Foto Profile</label>
        <input style="margin-top: 10px" type="file" id="fileimg1" accept="image/*" name="photo">
        <img style="margin-left: 20px" width="100px" height="auto" src="/gambar/user/<?php echo e(Auth::user()->photo); ?>">
        <?php if ($errors->has('photo')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('photo'); ?>
        <div class="invalid-feedback">
            <?php echo e($message); ?>

        </div>
        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
    </fieldset>
    <fieldset>
        <button name="submit" type="submit" id="contact-submit" data-submit="...Sending">Simpan</button>
    </fieldset>
</form>
<form id="form" action="/password/<?php echo e(Auth::user()->id); ?>" method="post">
    <?php echo csrf_field(); ?>
    <label for="">Perbarui Password</label>
    <fieldset>
        <input placeholder="Password" type="password" autocomplete="off" name="password" value="<?php echo e(old('password')); ?>" tabindex="1" required oninvalid="this.setCustomValidity('Data tidak boleh kosong')" oninput="setCustomValidity('')" autofocus>
        <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
        <div class="invalid-feedback">
            <?php echo e($message); ?>

        </div>
        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?> 
    </fieldset>
    <fieldset>
        <input placeholder="Konfirmasi Password" type="password" autocomplete="off" name="passwordc" value="<?php echo e(old('passwordc')); ?>" tabindex="1" required oninvalid="this.setCustomValidity('Data tidak boleh kosong')" oninput="setCustomValidity('')" autofocus>
        <?php if ($errors->has('passwordc')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('passwordc'); ?>
        <div class="invalid-feedback">
            <?php echo e($message); ?>

        </div>
        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?> 
    </fieldset>
    <fieldset>
        <button name="submit" type="submit" id="contact-submit" data-submit="...Sending">Simpan</button>
    </fieldset>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('super.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\TA\projek\program\master\resources\views/super/profile.blade.php ENDPATH**/ ?>