<form action="/post" method="post">
    <?php echo csrf_field(); ?>
    <input type="text" name="try">
    <input type="submit" value="ok">
</form><?php /**PATH D:\Kuliah\TA\projek\program\master\resources\views/send.blade.php ENDPATH**/ ?>