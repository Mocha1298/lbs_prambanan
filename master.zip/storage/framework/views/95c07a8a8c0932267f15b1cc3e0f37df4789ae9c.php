<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/png" href="<?php echo e(asset('/gambar/logo/logo.png')); ?>">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <script src="https://use.fontawesome.com/46ea1af652.js"></script>
    <link rel="stylesheet" href="<?php echo e(asset('style_admin/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('style_admin/dropdown-user.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('style_admin/popup.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('style_admin/notifikasi.css')); ?>">
    <script src="<?php echo e(asset('jquery/jquery.js')); ?>"></script>
    <script src="https://js.pusher.com/6.0/pusher.min.js"></script>
    <script src="<?php echo e(asset('js_admin/nav.js')); ?>"></script>
    <?php echo $__env->yieldContent('head'); ?>
</head>
<body <?php echo $__env->yieldContent('copy'); ?> >
    <div class="container">
        <header>
            <h2 class="bagian header">
              <div class="notif" onclick="stop();">
                <?php if(Auth::user()->roles_id == 2): ?>
                  <a href="/suwar_admin/<?php echo e(Auth::user()->villages_id); ?>">
                    <div id="notification" class="notification" data-count="0"></div>
                  </a>
                <?php endif; ?>
              </div>
              <span class="log">
                <label for="profile2" class="profile-dropdown">
                    <input type="checkbox" id="profile2">
                    <img src="/gambar/user/<?php echo e(Auth::user()->photo); ?>">
                    <span><?php echo e(auth()->user()->nama); ?></span>
                    <label for="profile2"><i class="mdi mdi-menu"></i></label>
                    <ul>
                      <li><a class="dropdown-item" href="/">Home</a></li>
                      <li><a class="dropdown-item" href="/profile/<?php echo e(Auth::user()->id); ?>">Profile</a></li>
                      <li><a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();document.getElementById('logout-form').submit();"><?php echo e(__('Logout')); ?></a>
                     <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                         <?php echo csrf_field(); ?>
                     </form></li>
                    </ul>
                  </label>
                </span>
            </h2>
        </header>
        <div class="background"></div>
        <nav>
          <ul>
            <li><a class="bagian dashboard" href="/admin"><span class='fa fa-home'></span>Dashboard</a></li>
            <?php if(Auth::user()->roles_id == 1): ?>
            
            <li class="topmenu">
                <div id="opener1">
                  <a href="#1" id="1" class="bagian pages" onclick="return show(1);">
                    <span class='fa fa-bookmark'></span>Olah Master
                  </a>
                </div>
                <ul class="submenu">
                  <div id="submenu1" style="display:none;">
                    <li>
                      <a class="bagian pages" href="/master_kecamatan"><span class='fa fa-bookmark'></span>Kecamatan</a>
                    </li>
                    <li>
                      <a class="bagian pages" href="/master_jenis"><span class='fa fa-bookmark'></span>Jenis Objek</a>
                    </li>
                    <li>
                      <a class="bagian pages" href="/master_user"><span class='fa fa-bookmark'></span>User</a>
                    </li>
                  </div> 
                </ul>
            </li>
            <?php endif; ?>
            
            <li class="topmenu">
              <div id="opener2">
                <a href="#2" id="2" class="bagian navigation" name="2" onclick="return show(2);">
                  <span class='fa fa-share'></span>Olah Objek
                </a>
              </div>
              <ul class="submenu">
                <div id="submenu2" style="display:none;">
                  <?php if(Auth::user()->roles_id == 1): ?>
                  <li>
                    <a class="bagian navigation" href="/objek_peta"><span class='fa fa-share'></span>Objek Peta</a>
                  </li>
                  <?php else: ?>
                  <li>
                    <a class="bagian navigation" href="/objek_kerusakan/<?php echo e(Auth::user()->villages_id); ?>"><span class='fa fa-share'></span>Kerusakan</a>
                  </li>
                  <?php endif; ?>
                </div> 
              </ul>
            </li>
            <?php if(Auth::user()->roles_id == 2): ?>
              
              <li class="topmenu">
                <div id="opener3">
                  <a href="#3" id="3" class="bagian users" name="3" onclick="return show(3);">
                    <span class='fa fa-user'></span>Suara Warga
                  </a>
                </div>
                <ul class="submenu">
                    <div id="submenu3" style="display:none;">
                      <li>
                      <a class="bagian users" href="/suwar_admin/<?php echo e(Auth::user()->villages_id); ?>"><span class='fa fa-user'></span>Laporan</a>
                      </li>
                      <li>
                        <a class="bagian users" href="/agenda/<?php echo e(Auth::user()->villages_id); ?>"><span class='fa fa-user'></span>Agenda</a>
                      </li>
                    </div> 
                </ul>
              </li>
            <?php endif; ?>
          </ul>
        </nav>
        <div class="content">
          <div class="main">
            <div class="breadcrump">
                <p><?php echo $__env->yieldContent('breadcrump'); ?></p>
            </div>
            <hr>
            <?php if(session('simpan')): ?>
            <div class="success"><i class="fa fa-check-circle-o fa-2x" aria-hidden="true"></i><?php echo e(session('simpan')); ?></div>
            <?php elseif(session('edit')): ?>
            <div class="warning"><i class="fa fa-pencil-circle-o fa-2x" aria-hidden="true"></i><?php echo e(session('edit')); ?></div>
            <?php elseif(session('hapus')): ?>
            <div class="error"><i class="fa fa-trash fa-2x" aria-hidden="true"></i><?php echo e(session('hapus')); ?></div>
            <?php elseif(session('gagal')): ?>
            <div class="error"><i class="fa fa-times-circle-o fa-2x" aria-hidden="true"></i><?php echo e(session('gagal')); ?></div>
            <?php endif; ?>
            
            <?php echo $__env->yieldContent('isi'); ?>
          </div>
        </div>
    </div>
      
  <div id="notif" class="overlay">
    <div class="popup">
      <h2 style="text-align: center">NOTIFIKASI</h2>
      <a href="#" class="close">&times;</a>
      <div class="content">
        
      </div>
    </div>
  </div>
    <?php echo $__env->yieldContent('script'); ?>
    <script>
      var id = <?php echo e(Auth::user()->id); ?>;
      console.log(id);
      var bell = document.getElementById('notification');
      // Enable pusher logging - don't include this in production
      Pusher.logToConsole = true;

      var pusher = new Pusher('c70441997e3d2b65ebed', {
        cluster: 'ap1',
        forceTLS: true
      });

      var count = 0

      var channel = pusher.subscribe('my-channel');
      channel.bind('App\\Events\\sendName', function(data) {
        if(id == data.id){
          count = Number(bell.attributes[2].nodeValue);
          bell.setAttribute('data-count', count + 1);
          console.log(bell.attributes[2].nodeValue);
          bell.classList.add('show-count');
          bell.classList.add('notify');
          alert('Ada Laporan Masuk. Silahkan Cek Laporan.');
        }
      });
      bell.addEventListener("animationend", function(event){
        bell.classList.remove('notify');
      });
    </script>
</body>
</html><?php /**PATH D:\Kuliah\TA\projek\program\master\resources\views/super/template.blade.php ENDPATH**/ ?>