<?php $__env->startSection('title','AGENDA SURVEY'); ?>

<?php $__env->startSection('head'); ?>
  <link rel="stylesheet" href="<?php echo e(asset('style_admin/table.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('style_admin/popup.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('style_admin/action.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('style_admin/form.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('style_admin/alert.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('style_admin/button.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('style_user/box-map.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('bs/pagination.css')); ?>">
  <style>
    #mapid{
      width: 100%;
      height: 500px;
    }
  </style>
  <script src="<?php echo e(asset('js_admin/nav.js')); ?>"></script>
  <link rel="stylesheet" href="https://unpkg.com/leaflet@1.6.0/dist/leaflet.css"
  integrity="sha512-xwE/Az9zrjBIphAcBb3F6JVqxf46+CDLwfLMHloNu6KEQCAWi6HcDUbeOfBIptF7tcCzusKFjFw2yuvEpDL9wQ=="
  crossorigin=""/>
  <script src="https://unpkg.com/leaflet@1.6.0/dist/leaflet.js"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('copy'); ?>
oncopy='return false' oncut='return false' onpaste='return false'
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrump'); ?>
    <?php if(Auth::user()->roles_id != 2): ?>
        <a href="/master_kecamatan">Master Kecamatan</a> > <a href="/master_desa_back/<?php echo e($id); ?>">Master Kerusakan</a> >Data Kerusakan
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('isi'); ?>
  <div class="isi">
    <a style="right: 0; width: 50px;" href="#map"><i style="width: 28px; height: 28px; color: mediumseagreen;" class="fa fa-globe fa-2x"></i></a>
    <table>
      <caption>Agenda Survey Laporan</caption>
      <thead>
        <tr>
          <th scope="col">No</th>
          <th scope="col">Judul</th>
          <th scope="col">RT/RW</th>
          <th scope="col">Foto</th>
          <th scope="col">Tanggal Survey</th>
          <th scope="col">Foto Survey</th>
        </tr>
      </thead>
      <?php if($count != 0): ?>
        <tbody>
          <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nomor => $sw): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr id="<?php echo e($sw->id); ?>" class="table">
              <td data-label="No"><?php echo e($nomor + $data->firstitem()); ?></td>
                <td data-label="Judul"><?php echo e($sw->nama); ?></td>
                <td data-label="RT/RW"><?php echo e($sw->rt); ?>/<?php echo e($sw->rw); ?></td>
                <td data-label="Foto"><a href="/gambar/laporan/ori/<?php echo e($sw->foto1); ?>"><img src="/gambar/laporan/thumbnail/<?php echo e($sw->foto1); ?>" width="100px" height="auto"></a></td>
                <td data-label="Tanggal Survey"><?php echo e($sw->survey); ?></td>
                <td data-label="Foto Survey">
                  <a href="/gambar/survey/ori/<?php echo e($sw->photo); ?>">
                    <img src="/gambar/survey/thumbnail/<?php echo e($sw->photo); ?>" alt="" width="100px" height="auto"> 
                  </a>
                </td>
                
                <div id="contextMenu" class="cm_<?php echo e($sw->id); ?>" style="display: none">
                    <ul class="dropdown-menu" role="menu" aria-labelledby="dropdownMenu" style="display:block;position:static;margin-bottom:5px;">
                    <li class="edit">
                        <a href="#popup_s<?php echo e($sw->id); ?>">EDIT</a>
                    </li>
                    <li class="detail">
                        <a href="#popup_v<?php echo e($sw->id); ?>">VALID</a>
                    </li>
                    </ul>
                </div>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      <?php else: ?>
        <tbody>
          <tr>Data masih kosong!</tr>
        </tbody>
      <?php endif; ?>
    </table>
    <?php echo e($data->links()); ?>

  </div>
  
<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sw): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div id="popup_s<?php echo e($sw->id); ?>" class="overlay">
    <div class="popup">
      <h2>Perbarui data</h2>
      <div class="content">
        <form id="form" action="/survey/<?php echo e($id); ?>" method="post">
          <?php echo e(csrf_field()); ?>

          <input type="reset" id="configreset" value="&times;" class="close" onclick="href();">
          <fieldset>
            <label for="">Tanggal Survey</label><br><br>
            <input placeholder="Tanggal Survey" type="date" autocomplete="off" name="survey" value="<?php echo e($sw->survey); ?>" tabindex="1" required oninvalid="this.setCustomValidity('Data tidak boleh kosong')" oninput="setCustomValidity('')">
            <label style="font-size: 12px; color: #888;" for="survey"></label>
            <?php if ($errors->has('survey')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('survey'); ?>
            <div class="invalid-feedback">
                <?php echo e($message); ?>

            </div>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
          </fieldset>
          <fieldset>
            <label for="">Foto Survey</label>
            <input style="margin-top: 10px" type="file" id="fileimg1" accept="image/*" name="foto">
            <img style="margin-left: 20px" width="50px" height="auto" src="/gambar/survey/thumbnail/<?php echo e($sw->photo); ?>" alt="">
            <?php if ($errors->has('foto1')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('foto1'); ?>
            <div class="invalid-feedback">
                <?php echo e($message); ?>

            </div>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
          </fieldset>
          <fieldset>
            <button name="submit" type="submit" id="contact-submit" data-submit="...Sending">Simpan</button>
          </fieldset>
      </form>
      </div>
    </div>
  </div>
  <div id="popup_v<?php echo e($sw->id); ?>" class="overlay">
    <div class="popup">
      <h2>MASUKKAN DATA KEDALAM KERUSAKAN?</h2>
      <div class="content">
        <fieldset class="acc">
          <a class="ya" href="/valid/<?php echo e($sw->id); ?>">YA, MASUKKAN.</a>
          <a class="cancel" href="#">Batal</a>
        </fieldset>
      </div>
    </div>
  </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<div id="map" class="overlay">
  <div class="popup">
    <h2>Peta Agenda</h2>
    <a href="#" class="close">&times;</a>
    <div class="content">
      <div id="mapid"></div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
    function href() {
      window.location.href = '#';
    }
  </script>
    <script src="<?php echo e(asset('js_admin/action.js')); ?>"></script>
    <script src="<?php echo e(asset('js_admin/bundle.js')); ?>"></script>
    <script src="<?php echo e(asset('js_admin/ajax.js')); ?>"></script>
    <script>
      $.getJSON("/center_desa", function (data){
          mymap = L.map('mapid',{
              center :  [data.lintang,data.bujur],
              watch : true,
              zoom: 16,
              // scrollWheelZoom: false,
              closePopupOnClick: false
          });
          var geojsonLayer = new L.GeoJSON.AJAX("/batas/"+data.batas,{
              fillOpacity : 0,
              color : 'white'
          });       
          geojsonLayer.addTo(mymap);
          L.tileLayer('http://{s}.google.com/vt/lyrs=s&x={x}&y={y}&z={z}',{
              minZoom: 10,
              maxZoom: 20,
              subdomains:['mt0','mt1','mt2','mt3']
          }).addTo(mymap);
      });
      $.getJSON("/datapeta_agenda", function (data1) {
          for (var i = 0; i < data1.length; i++) {
            var name = data1[i].nama;
            L.marker([data1[i].lintang, data1[i].bujur])
            .addTo(mymap)
            .bindPopup(
                (info =
                    "<div class='cont'>"
                        +"<div class='box'>"
                            +"<div class='header'>"
                                +"<h2><strong> Nama Laporan : "+name+"</strong></h2>"
                                +"<p> Keterangan : "+data1[i].keterangan+"</p>"
                                +"<p>RT/RW : "+data1[i].rt+"/"+data1[i].rw+" </p>"
                                +"<p><strong>Tanggal Survey: "+data1[i].survey+"</strong></p>"
                            +"</div>"
                            +"<img src='/gambar/laporan/thumbnail/"+data1[i].foto1+"' alt=''>"
                        +"</div>"
                    +"</div>"
                    )
            );
          }
      })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('super.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\TA\projek\program\master\resources\views/super/suwar/agenda.blade.php ENDPATH**/ ?>