<?php $__env->startSection('title','AGENDA SURVEY'); ?>

<?php $__env->startSection('head'); ?>
  <link rel="stylesheet" href="<?php echo e(asset('style_admin/table.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('style_admin/form.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('style_admin/action.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('style_admin/alert.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('style_admin/button.css')); ?>">
  <script src="<?php echo e(asset('jquery/jquery-3.5.1.slim.min.js')); ?>"></script>
  <script src="<?php echo e(asset('js_admin/nav.js')); ?>"></script>
  <link rel="stylesheet" href="https://unpkg.com/leaflet@1.6.0/dist/leaflet.css"
  integrity="sha512-xwE/Az9zrjBIphAcBb3F6JVqxf46+CDLwfLMHloNu6KEQCAWi6HcDUbeOfBIptF7tcCzusKFjFw2yuvEpDL9wQ=="
  crossorigin=""/>
  <script src="https://unpkg.com/leaflet@1.6.0/dist/leaflet.js"></script>
  <script src = "https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('copy'); ?>
oncopy='return false' oncut='return false' onpaste='return false'
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrump'); ?>
    <?php if(Auth::user()->roles_id != 2): ?>
        <a href="/master_kecamatan">Master Kecamatan</a> > <a href="/master_desa_back/<?php echo e($id); ?>">Master Kerusakan</a> >Data Kerusakan
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('isi'); ?>
  <div class="isi">
    <table>
      <caption>Agenda Survey Laporan</caption>
      <thead>
        <tr>
          <th scope="col">Judul</th>
          <th scope="col">RT/RW</th>
          <th scope="col">Foto</th>
          <th scope="col">Tanggal Survey</th>
          <th scope="col">Foto Survey</th>
        </tr>
      </thead>
      <?php if($count != 0): ?>
        <tbody>
          <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sw): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr id="<?php echo e($sw->id); ?>" class="table">
                <td data-label="Judul"><?php echo e($sw->nama); ?></td>
                <td data-label="RT/RW"><?php echo e($sw->rt); ?>/<?php echo e($sw->rw); ?></td>
                <td data-label="Foto"><a href="/gambar/laporan/ori/<?php echo e($sw->foto1); ?>"><img src="/gambar/laporan/thumbnail/<?php echo e($sw->foto1); ?>" width="100px" height="auto"></a></td>
                <td data-label="Tanggal Survey"><?php echo e($sw->survey); ?></td>
                <td data-label="Foto Survey">
                  <a href="/gambar/survey/ori/<?php echo e($sw->photo); ?>">
                    <img src="/gambar/survey/thumbnail/<?php echo e($sw->photo); ?>" alt="" width="100px" height="auto"> 
                  </a>
                </td>
                
                <div id="contextMenu" class="cm_<?php echo e($sw->id); ?>" style="display: none">
                    <ul class="dropdown-menu" role="menu" aria-labelledby="dropdownMenu" style="display:block;position:static;margin-bottom:5px;">
                    <li class="edit">
                        <a href="#popup_s<?php echo e($sw->id); ?>">EDIT</a>
                    </li>
                    <li class="detail">
                        <a href="/valid/<?php echo e($sw->id); ?>">VALID</a>
                    </li>
                    </ul>
                </div>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      <?php else: ?>
        <tbody>
          <tr>Data masih kosong!</tr>
        </tbody>
      <?php endif; ?>
    </table>
    <div class="pagination">
        <a style="right: 0; width: 50px;" href="#map"><i style="width: 28px; height: 28px; color: mediumseagreen;" class="fa fa-globe fa-2x"></i></a>
        <?php
          // config
          $link_limit = 10;
          ?>

          <?php if($data->lastPage() > 1): ?>
              <ul>
                  <li class="<?php echo e(($data->currentPage() == 1) ? ' disabled' : ''); ?>">
                      <a href="<?php echo e($data->url(1)); ?>">First</a>
                  </li>
                  <?php for($i = 1; $i <= $data->lastPage(); $i++): ?>
                      <?php
                      $half_total_links = floor($link_limit / 2);
                      $from = $data->currentPage() - $half_total_links;
                      $to = $data->currentPage() + $half_total_links;
                      if ($data->currentPage() < $half_total_links) {
                        $to += $half_total_links - $data->currentPage();
                      }
                      if ($data->lastPage() - $data->currentPage() < $half_total_links) {
                          $from -= $half_total_links - ($data->lastPage() - $data->currentPage()) - 1;
                      }
                      ?>
                      <?php if($from < $i && $i < $to): ?>
                          <li class="<?php echo e(($data->currentPage() == $i) ? ' active' : ''); ?>">
                              <a href="<?php echo e($data->url($i)); ?>"><?php echo e($i); ?></a>
                          </li>
                      <?php endif; ?>
                  <?php endfor; ?>
                  <li class="<?php echo e(($data->currentPage() == $data->lastPage()) ? ' disabled' : ''); ?>">
                      <a href="<?php echo e($data->url($data->lastPage())); ?>">Last</a>
                  </li>
              </ul>
          <?php endif; ?>
    </div>
  </div>
  
  <div id="popup_s<?php echo e($sw->id); ?>" class="overlay">
    <div class="popup">
      <h2>Perbarui data</h2>
      <div class="content">
        <form id="form" action="/survey/<?php echo e($id); ?>" method="post">
          <?php echo e(csrf_field()); ?>

          <input type="reset" id="configreset" value="&times;" class="close" onclick="href();">
          <fieldset>
            <label for="">Tanggal Survey</label><br><br>
            <input placeholder="Tanggal Survey" type="date" autocomplete="off" name="survey" value="<?php echo e($sw->survey); ?>" tabindex="1" required oninvalid="this.setCustomValidity('Data tidak boleh kosong')" oninput="setCustomValidity('')">
            <label style="font-size: 12px; color: #888;" for="survey"></label>
            <?php if ($errors->has('survey')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('survey'); ?>
            <div class="invalid-feedback">
                <?php echo e($message); ?>

            </div>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
          </fieldset>
          <fieldset>
            <label for="">Foto Survey</label>
            <input style="margin-top: 10px" type="file" id="fileimg1" accept="image/*" name="foto">
            <img style="margin-left: 20px" width="50px" height="auto" src="/gambar/survey/thumbnail/<?php echo e($sw->photo); ?>" alt="">
            <?php if ($errors->has('foto1')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('foto1'); ?>
            <div class="invalid-feedback">
                <?php echo e($message); ?>

            </div>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>          </fieldset>
          <fieldset>
            <button name="submit" type="submit" id="contact-submit" data-submit="...Sending">Simpan</button>
          </fieldset>
      </form>
      </div>
    </div>
  </div>
  <div id="popup_v<?php echo e($sw->id); ?>" class="overlay">
    <div class="popup">
      <h2>MASUKKAN DATA KEDALAM KERUSAKAN?</h2>
      <div class="content">
        <fieldset class="acc">
          <a class="ya" href="/valid/<?php echo e($sw->id); ?>">YA, MASUKKAN.</a>
          <a class="cancel" href="#">Batal</a>
        </fieldset>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
    function href() {
      window.location.href = '#';
    }
  </script>
    <script src="<?php echo e(asset('js_admin/action.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('super.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\TA\projek\program\master\resources\views/super/suwar/agenda.blade.php ENDPATH**/ ?>