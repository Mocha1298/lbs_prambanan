window.LRM = {
	apiToken: 'pk.eyJ1IjoibGllZG1hbiIsImEiOiJjazIwZGZvOXkwemQ5M211Z3B3c2M5bmpvIn0.Q8TUG4ornnhqO9ApeU3ZUQ'
};