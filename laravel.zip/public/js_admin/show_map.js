// MAPSS SAYA
var mymap;
var bujur;
var lintang;

$.getJSON("/center", function (data){
    mymap = L.map('mapid',{
        center :  [data.lintang,data.bujur],
        watch : true,
        zoom: 14,
        scrollWheelZoom: false,
    });
    L.geoJSON([prambanan]).addTo(mymap);
    L.tileLayer('http://{s}.google.com/vt/lyrs=s&x={x}&y={y}&z={z}',{
        minZoom: 10,
        maxZoom: 20,
        subdomains:['mt0','mt1','mt2','mt3']
    }).addTo(mymap);
});

var layerGroup1 = L.layerGroup();
var layerGroup2 = L.layerGroup();

var popup = L.popup({
    closeButton: false
});

var objek = []; //OBJEK PETA
function show_objek() {
    $.getJSON("/objek", function (data) {
        for (var i = 0; i < data.length; i++) {
           var icon = L.icon({
               iconUrl: '/gambar/jenis/'+data[i].marker,
               iconSize:     [25, 25],
           });
           var name = data[i].nama;
           objek[i] = L.marker([data[i].lintang, data[i].bujur],{icon: icon}).addTo(mymap)
           .bindPopup(
               (info =
                   "<div class='cont'>"+
                       "<div class='box'>"+
                           "<div class='header'>"+
                               "<h2><strong>"+name+"</strong></h2>"+
                           "</div>"+
                           "<img src='/gambar/objek/thumbnail/"+data[i].foto1+"' alt='' width='100%' height='auto'>"+
                           "<a id='done' onclick='make_dst("+data[i].lintang+","+data[i].bujur+");'>Rute</a>"+
                       "</div>"+
                   "</div>"
               )
           );
           layerGroup1.addLayer(objek[i]).addTo(mymap);
        }
   })
}
show_objek();

function hide(x) {
    if(x == 0){
        for (var i = 0; i < objek.length; i++){
            layerGroup1.removeLayer(objek[i])
        }
        $('#show')[0].attributes.onclick.nodeValue = "hide(1);";
        $('#show')[0].innerText = "Show Object";
    }
    else{
        show_objek();
        $('#show')[0].attributes.onclick.nodeValue = "hide(0);";
        $('#show')[0].innerText = "Clear Object";
    }
}

var kerusakan = [];//KERUSAKAN

function show_kr() {
    $.getJSON("/datapeta", function (data1) {
        for (var i = 0; i < kerusakan.length; i++){
            layerGroup2.removeLayer(kerusakan[i]);
        }
        for (var i = 0; i < data1.length; i++) {
            var icon = L.icon({
                iconUrl: '/gambar/jenis/'+data1[i].marker,
                iconSize:     [30, 30],
            });
            var name = data1[i].kerusakan;
            var status = data1[i].status;
            kerusakan[i] = L.marker([data1[i].lintang, data1[i].bujur],{icon: icon})
            .addTo(mymap)
            .bindPopup(
                (info =
                    "<div class='cont'>"
                        +"<div class='box'>"
                            +"<div class='header'>"
                                +"<h2><strong>"+name+"</strong></h2>"
                                +"<p>Desa : "+data1[i].desa+" </p>"
                                +"<p>RT/RW : "+data1[i].rt+"/"+data1[i].rw+" </p>"
                            +"</div>"
                            +"<img src='/gambar/kerusakan/thumbnail/"
                            +(status == 'Rencana' ? data1[i].foto1 : "")
                            +(status == 'Sedang' ? data1[i].foto2 : "")
                            +(status == 'Selesai' ? data1[i].foto3 : "")
                            +"' alt=''>"
                            +"<a id='jos' onclick='return show("+data1[i].id+");'>Detail<i class='fa fa-arrow-circle-right'></a>"
                            +"</a>"
                        +"</div>"
                    +"</div>"
                    )
            );
            layerGroup2.addLayer(kerusakan[i]).addTo(mymap);
        }
    })
}
show_kr();

$("select#desa").change(function(){
    var desa = $(this).children(":selected")[0].innerText;
    if(desa == "--Desa--"){
        show_kr();
    }
    else{
        $.getJSON("/datapeta", function (data1) {
            for (var i = 0; i < kerusakan.length; i++){
                layerGroup2.removeLayer(kerusakan[i]);
            }
            for (var i = 0; i < data1.length; i++) {
                var icon = L.icon({
                    iconUrl: '/gambar/jenis/'+data1[i].marker,
                    iconSize:     [30, 30],
                });
                if (desa == data1[i].desa) {
                    var name = data1[i].kerusakan;
                    var status = data1[i].status;
                    kerusakan[i] = L.marker([data1[i].lintang, data1[i].bujur],{icon: icon})
                    .addTo(mymap)
                    .bindPopup(
                        (info =
                            "<div class='cont'>"
                                +"<div class='box'>"
                                    +"<div class='header'>"
                                        +"<h2><strong>"+name+"</strong></h2>"
                                        +"<p>Desa : "+data1[i].desa+" </p>"
                                        +"<p>RT/RW : "+data1[i].rt+"/"+data1[i].rw+" </p>"
                                    +"</div>"
                                    +"<img src='/gambar/kerusakan/thumbnail/"
                                    +(status == 'Rencana' ? data1[i].foto1 : "")
                                    +(status == 'Sedang' ? data1[i].foto2 : "")
                                    +(status == 'Selesai' ? data1[i].foto3 : "")
                                    +"' alt=''>"
                                    +"<a id='jos' onclick='return show("+data1[i].id+");'>Detail<i class='fa fa-arrow-circle-right'></a>"
                                    +"</a>"
                                +"</div>"
                            +"</div>"
                        )
                    );
                    layerGroup2.addLayer(kerusakan[i]).addTo(mymap);
                }
            }
        })
    }
});

function make_dst(l,b) {
    locateUser();
    var control = L.Routing.control({
            waypoints: [
                L.latLng(lintang,bujur),
                L.latLng(l,b)
            ],
            routeWhileDragging: true
        })
        .on('routingerror', function(e) {
            try {
                mymap.getCenter();
            } catch (e) {
                mymap.fitBounds(L.latLngBounds(control.getWaypoints().map(function(wp) { return wp.latLng; })));
            }
    
            handleError(e);
        })
        .addTo(mymap);
    
    L.Routing.errorControl(control).addTo(mymap);
    $('#done')[0].innerText = "SELESAI";
    $('#done')[0].attributes.onclick.nodeValue = "done();";
}

function done() {
    window.location.reload();
}

function locateUser() {
    mymap.locate({
        setView : true,
        minZoom: 10,
        maxZoom: 20
    });

	function onLocationFound(e) {
		var radius = e.accuracy / 2;

		L.marker(e.latlng).addTo(mymap)
			.bindPopup("You are within " + radius + " meters from this point").openPopup();
        lintang = e.latitude;
        bujur = e.longitude;
		L.circle(e.latlng, radius).addTo(mymap);
	}

	function onLocationError(e) {
		alert(e.message);
	}

	mymap.on('locationfound', onLocationFound);
	mymap.on('locationerror', onLocationError);
}

// var current_position, current_accuracy;

// function onLocationFound(e) {
//   // if position defined, then remove the existing position marker and accuracy circle from the map
//   if (current_position) {
//       mymap.removeLayer(current_position);
//       mymap.removeLayer(current_accuracy);
//   }

//   var radius = e.accuracy / 2;

//   current_position = L.marker(e.latlng).addTo(mymap)
//     .bindPopup("You are within " + radius + " meters from this point").openPopup();

//   current_accuracy = L.circle(e.latlng, radius).addTo(map);
// }

// function onLocationError(e) {
//   alert(e.message);
// }

// mymap.on('locationfound', onLocationFound);
// mymap.on('locationerror', onLocationError);

// // wrap map.locate in a function    
// function locate() {
//   mymap.locate({setView: true, maxZoom: 16});
// }

// // call locate every 3 seconds... forever
// setInterval(locate, 3000);










































// FOUND MY LOCATION
// function onLocationFound(e) {
//     var radius = e.accuracy / 2;

//     L.marker(e.latlng).addTo(mymap)
//         .bindPopup("Lokasi Anda ada didalam radius " + radius + "meter.").openPopup();
// }

// function onLocationError(e) {
//     alert(e.message);
// }

// mymap.on('locationfound', onLocationFound);
// mymap.on('locationerror', onLocationError);

// mymap.locate({setView: true});

// navigator.geolocation.getCurrentPosition(function(location) {
//     latlng = new L.LatLng(location.coords.latitude, location.coords.longitude);

//     L.Routing.control({
//         waypoints: [
//           L.latLng(lintang, bujur),
//           L.latLng(-7.744464, 110.494553)
//         ]
//       }).addTo(mymap);   
  
//     var current = L.icon({
//         iconUrl: '/gambar/marker/current.png',
//         iconSize:     [17, 17], // Ukuran
//         iconAnchor:   [8, 13], // Posisi marker
//         popupAnchor:  [-13, -5], // Posisi Popup muncul
//         tooltipAnchor: [9,-20], //Alhamdulillah nemu bind tool up e aku :D
//     });

//     var marker = L.marker(latlng,{icon:current}).addTo(mymap).bindPopup("Lokasi Anda");
// }); 

// var control = L.Routing.control({
//     router: L.routing.mapbox(LRM.apiToken),
//     plan: L.Routing.plan(waypoints, {
//         createMarker: function(i, wp) {
//             return L.marker(wp.latLng, {
//                 // draggable: true,
//                 icon: L.icon.glyph({ glyph: String.fromCharCode(65 + i) })
//             });
//         },
//         geocoder: L.Control.Geocoder.nominatim(),
//         // routeWhileDragging: true
//     }),
//     routeWhileDragging: true,
//     routeDragTimeout: 250,
//     showAlternatives: true,
//     altLineOptions: {
//         styles: [
//             {color: 'black', opacity: 0.15, weight: 9},
//             {color: 'white', opacity: 0.8, weight: 6},
//             {color: 'blue', opacity: 0.5, weight: 2}
//         ]
//     }
// })
// .addTo(mymap)
// .on('routingerror', function(e) {
//     try {
//         map.getCenter();
//     } catch (e) {
//         map.fitBounds(L.latLngBounds(waypoints));
//     }

//     handleError(e);
// });

// L.Routing.errorControl(control).addTo(mymap);