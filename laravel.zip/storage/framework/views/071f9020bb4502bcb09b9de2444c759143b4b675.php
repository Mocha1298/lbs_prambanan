<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="<?php echo e(asset('style_user/my_suwar.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('style_admin/table.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('style_admin/popup.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('style_admin/form.css')); ?>">
    <script src="https://use.fontawesome.com/46ea1af652.js"></script>
    <script src="<?php echo e(asset('jquery/jquery.js')); ?>"></script>
    <link href="https://fonts.googleapis.com/css?family=Amatic+SC|Raleway" rel="stylesheet">
    <title>Laporan Anda</title>
</head>
<body>
    <header class="topnav" id="myTopnav">
        <a href="/" style="
        font-family: 'Amatic SC', sans-serif;
        color: whitesmoke;
        text-decoration: none;
        font-size: 35px;
        ">Peta-Jalan</a>
        <div class="navlist" id="navlist">
            <a class="cursor0" href="#home">&nbsp</a>
            <a class="navoption" href="/">Home</a>
            <a class="navoption" href="#edit">Profile</a>
            <a class="navoption" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();document.getElementById('logout-form').submit();">Logout</a>
            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
              <?php echo csrf_field(); ?>
            </form>
            <a href="javascript:void(0);" class="icon" id="hamburger">
                <i class="fa fa-bars"></i>
            </a>
        </div>
    </header>

    <table>
        <caption>Laporan Saya</caption>
        <thead>
          <tr>
            <th scope="col">No</th>
            <th scope="col">Judul</th>
            <th scope="col">RT/RW</th>
            <th scope="col">Desa</th>
            <th scope="col">Foto</th>
            <th scope="col">Status</th>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sw): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr id="<?php echo e($sw->id); ?>" class="table">
              <td data-label="No"><?php echo e($loop->iteration); ?></td>
              <td data-label="Judul"><?php echo e($sw->nama); ?></td>
              <td data-label="RT/RW"><?php echo e($sw->rt); ?>/<?php echo e($sw->rw); ?></td>
              <td data-label="Desa"><?php echo e($sw->nama_desa); ?></td>
              <td data-label="Foto"><a href="/gambar/laporan/ori/<?php echo e($sw->foto1); ?>"><img src="/gambar/laporan/thumbnail/<?php echo e($sw->foto1); ?>" width="100px" height="auto"></a></td>
              <td data-label="Status" style="color:white;background: <?php if($sw->status==1): ?> dodgerblue <?php elseif($sw->status==2): ?> forestgreen <?php else: ?> indianred <?php endif; ?>"><?php if($sw->status==1): ?> Diterima <?php elseif($sw->status==2): ?> Disetujui <?php else: ?> Ditunda <?php endif; ?></td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <div class="pagination">
        <a style="color:white; padding: 10px;" href="/suwar"><i class="fa fa-plus fa-2x"></i></a>
        <?php
          // config
          $link_limit = 10;
          ?>

          <?php if($data->lastPage() > 1): ?>
              <ul style="background: white;">
                  <li class="<?php echo e(($data->currentPage() == 1) ? ' disabled' : ''); ?>">
                      <a href="<?php echo e($data->url(1)); ?>">First</a>
                  </li>
                  <?php for($i = 1; $i <= $data->lastPage(); $i++): ?>
                      <?php
                      $half_total_links = floor($link_limit / 2);
                      $from = $data->currentPage() - $half_total_links;
                      $to = $data->currentPage() + $half_total_links;
                      if ($data->currentPage() < $half_total_links) {
                        $to += $half_total_links - $data->currentPage();
                      }
                      if ($data->lastPage() - $data->currentPage() < $half_total_links) {
                          $from -= $half_total_links - ($data->lastPage() - $data->currentPage()) - 1;
                      }
                      ?>
                      <?php if($from < $i && $i < $to): ?>
                          <li class="<?php echo e(($data->currentPage() == $i) ? ' active' : ''); ?>">
                              <a href="<?php echo e($data->url($i)); ?>"><?php echo e($i); ?></a>
                          </li>
                      <?php endif; ?>
                  <?php endfor; ?>
                  <li class="<?php echo e(($data->currentPage() == $data->lastPage()) ? ' disabled' : ''); ?>">
                      <a href="<?php echo e($data->url($data->lastPage())); ?>">Last</a>
                  </li>
              </ul>
          <?php endif; ?>
    </div>
      
      <div id="edit" class="overlay">
        <div class="popup">
          <h2>Form Ubah Data Pengguna</h2>
          <div class="content">
            <form id="form" action="/ubah_display/<?php echo e(Auth::user()->id); ?>" method="post">
              <?php echo e(csrf_field()); ?>

              <input type="reset" id="configreset" value="&times;" class="close" onclick="href();">
              <label for="">Nama dan Email</label>
              <fieldset>
              <input placeholder="Nama User" autocomplete="off" type="text" name="nama" value="<?php echo e(Auth::user()->nama ?? old('nama')); ?>" tabindex="1" required oninvalid="this.setCustomValidity('Data tidak boleh kosong')" oninput="setCustomValidity('')" autofocus>
              <?php if ($errors->has('nama')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nama'); ?>
              <div class="invalid-feedback">
                  <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                <input placeholder="Email" autocomplete="off" type="email" name="email" value="<?php echo e(Auth::user()->email ?? old('email')); ?>" tabindex="2" required oninvalid="this.setCustomValidity('Data tidak boleh kosong')" oninput="setCustomValidity('')">
                <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                <div class="invalid-feedback">
                  <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
              </fieldset>
              <fieldset>
                <button name="submit" type="submit" id="contact-submit" data-submit="...Sending">Simpan</button>
              </fieldset>
            </form> 
            <form id="form" action="/ubah_password/<?php echo e(Auth::user()->id); ?>" method="post">
              <label for="">Perbarui Password</label>
              <fieldset>
                <input placeholder="Password Baru" type="password" name="password" value="<?php echo e(old('password')); ?>" tabindex="2" required oninvalid="this.setCustomValidity('Data tidak boleh kosong')" oninput="setCustomValidity('')">
                <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                <div class="invalid-feedback">
                    <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                <input placeholder="Konfirmasi Password Baru" autocomplete="off" type="email" name="email" value="<?php echo e(old('email')); ?>" tabindex="2" required oninvalid="this.setCustomValidity('Data tidak boleh kosong')" oninput="setCustomValidity('')">
                <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                <div class="invalid-feedback">
                    <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
              </fieldset>         
              <fieldset>
                <button name="submit" type="submit" id="contact-submit" data-submit="...Sending">Simpan</button>
              </fieldset>
            </form>
          </div>
        </div>
      </div>
    <script>
        $( document ).ready(function() {

        var opcionesnav = $('.navoption').length;
        var clickhamb=0;

        $("#hamburger").click(function(){
            clickhamb = 1;
            var header = $("#myTopnav");
            if (header[0].classList.length == 1) {
                header.addClass ("responsive");
                $("header").height((opcionesnav+1)*48);
                $(".navlist a:not(.icon)").css("display", "block");
                setTimeout(
                    function()
                    {
                        $(".navlist a:not(.icon)").css("transform", "translateX(0px)");
                    }, 50);

            } else {
                $(".navlist a:not(.icon)").css("transform", "translateX(600px)");
                header.height(48);
                setTimeout(
                    function()
                    {
                        header.removeClass("responsive");
                        header.height(48);
                        $(".navlist a:not(.icon)").css("display", "none");
                    }, 1600);
            }
        });


        $(window).on('resize', function(){
            if (($(window).width() > 600) && (clickhamb==1)){
                console.log(clickhamb + "     " + $(window).width());
                $("#myTopnav").height(48);
                $(".navlist a:not(.icon)").css("display", "block");
                setTimeout(
                    function()
                    {
                        $(".navlist a:not(.icon)").css("transform", "translateX(0px)");
                    }, 500);
            }
        });

        });
    </script>
    <script>
      function href() {
        window.location.href = '#';
      }
    </script>
</body>
</html><?php /**PATH D:\Kuliah\TA\projek\program\master\resources\views/user/my_suwar.blade.php ENDPATH**/ ?>