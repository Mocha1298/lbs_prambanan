<?php $__env->startSection('head'); ?>
<link rel="stylesheet" href="<?php echo e(asset('style_user/suwar.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('style_admin/alert.css')); ?>">

<link rel="stylesheet" href="https://unpkg.com/leaflet@1.6.0/dist/leaflet.css"
integrity="sha512-xwE/Az9zrjBIphAcBb3F6JVqxf46+CDLwfLMHloNu6KEQCAWi6HcDUbeOfBIptF7tcCzusKFjFw2yuvEpDL9wQ=="
crossorigin=""/>
<script src="https://unpkg.com/leaflet@1.6.0/dist/leaflet.js"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title','SUARA WARGA'); ?>
<?php $__env->startSection('isi'); ?>
<?php $__env->startSection('profile'); ?>
<a class="navoption" href="/my_suwar/<?php echo e(Auth::user()->id); ?>">Profile</a>
<?php $__env->stopSection(); ?>
  <div class="judul">
    <h3 id="logo">Suara Warga</h3>
  </div>
  <form method="post" action="/post_suwar" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <?php if(session('simpan')): ?>
    <div class="success"><i class="fa fa-check-circle-o fa-2x" aria-hidden="true"></i><?php echo e(session('simpan')); ?></div>
    <?php endif; ?>

    <label for="nama">Judul Laporan</label>
    <input type="text" id="nama" name="nama" placeholder="Tulis Judul laporan Anda.." value="<?php echo e(old('nama')); ?>" autocomplete="off" required maxlength="50"/>
    <?php if ($errors->has('nama')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nama'); ?>
    <div class="invalid-feedback">
        <?php echo e($message); ?>

    </div>
    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
    <br>

    <label for="keterangan">Keterangan</label>
    <input type="text" id="keterangan" name="keterangan" placeholder="Tulis Keterangan laporan Anda.." value="<?php echo e(old('keterangan')); ?>" autocomplete="off" required maxlength="200"/>
    <?php if ($errors->has('keterangan')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('keterangan'); ?>
    <div class="invalid-feedback">
        <?php echo e($message); ?>

    </div>
    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
    <br>

    <label for="desa">DESA</label>
    <select name="desa">
      <option class="dis" <?php if(old('desa') == ''): ?> selected <?php endif; ?> disabled>Pilih Desa laporan Anda..</option>
      <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option <?php if(old('desa') == $dt->id): ?> selected <?php endif; ?> value="<?php echo e($dt->id); ?>"><?php echo e($dt->nama); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <?php if ($errors->has('desa')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('desa'); ?>
    <div class="invalid-feedback">
        <?php echo e($message); ?>

    </div>
    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
    <br>
    
    <label for="rw">RW (optional)</label>
    <input type="text" id="rw" name="rw" placeholder="Tulis  laporan Anda.." value="<?php echo e(old('rw')); ?>" autocomplete="off" />
    <?php if ($errors->has('rw')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('rw'); ?>
    <div class="invalid-feedback">
        <?php echo e($message); ?>

    </div>
    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
    <br>
    
    <label for="rt">RT (optional)</label>
    <input type="text" id="rt" name="rt" placeholder="Tulis judul laporan Anda.." value="<?php echo e(old('rt')); ?>" autocomplete="off" />
    <?php if ($errors->has('rt')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('rt'); ?>
    <div class="invalid-feedback">
        <?php echo e($message); ?>

    </div>
    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
    <br>

    <label for="foto1">Foto Laporan</label>
    <input style="margin-top: 10px" type="file" accept="image/*" name="foto1">
    <?php if ($errors->has('foto1')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('foto1'); ?>
    <div class="invalid-feedback">
        <?php echo e($message); ?>

    </div>
    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
    <br>

    <input id="bujur" placeholder="Longitude" type="text" name="bujur" value="<?php echo e(old('bujur')); ?>" required oninvalid="this.setCustomValidity('Data tidak boleh kosong')" oninput="setCustomValidity('')" readonly>
    <?php if ($errors->has('bujur')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('bujur'); ?>
    <div class="invalid-feedback">
        <?php echo e($message); ?>

    </div>
    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
    <br>

    <input id="lintang" placeholder="Latitude" type="text" name="lintang" value="<?php echo e(old('lintang')); ?>" required oninvalid="this.setCustomValidity('Data tidak boleh kosong')" oninput="setCustomValidity('')" readonly>
    <?php if ($errors->has('lintang')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('lintang'); ?>
    <div class="invalid-feedback">
        <?php echo e($message); ?>

    </div>
    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
    <br>

    <div onmousemove="getcenter1();" id="mapid" style="width: 100%; height: 35vh;margin-bottom: 20px">
      <img class="marker" src="<?php echo e(asset('gambar/marker/marker.png')); ?>" alt="">
    </div>

    <label style="width: 100%" for="captcha">Captcha</label>
    <div class="captcha">
      <span><?php echo captcha_img(); ?></span>
    </div>
    <div class="btn-refresh">
      <button id="refresh" type="button" class="refresh"><i class="fa fa-refresh"></i></button>
    </div>

    <input id="captcha" type="text" placeholder="Masukan Captcha" name="captcha" autocomplete="off" required>
    <?php if ($errors->has('captcha')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('captcha'); ?>
    <div class="invalid-feedback">
        <?php echo e($message); ?>

    </div>
    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

    <input type="submit" name="submit" value="Kirim" />

  </form>
  <script type="text/javascript">
    $('#refresh').click(function(){
        $.ajax({
          type:'GET',
          url:'refreshcaptcha',
          success:function(data){
              $(".captcha span").html(data.captcha);
          }
        });
      });
  </script>
  <script src="<?php echo e(asset('js_admin/action.js')); ?>"></script>
  <script src="<?php echo e(asset('js_admin/bundle.js')); ?>"></script>
  <script src="<?php echo e(asset('js_admin/polygon.js')); ?>"></script>
  <script src="<?php echo e(asset('js_admin/crud_map.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.lay', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\TA\projek\program\master\resources\views/user/suara_warga.blade.php ENDPATH**/ ?>