<?php $__env->startSection('title','PENGGUNA'); ?>

<?php $__env->startSection('head'); ?>
  <link rel="stylesheet" href="<?php echo e(asset('style_admin/table.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('style_admin/form.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('style_admin/action.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('style_admin/alert.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('style_admin/button.css')); ?>">
  <style>
      .main .pagination a.button{
        color: black;
        background-color: #d95235;
        padding: 5px 10px;
        border-radius: 15px;
        -webkit-box-shadow: 4px 4px 5px 1px #ccc;
        -moz-box-shadow:    4px 4px 5px 1px #ccc;
        box-shadow:         4px 4px 5px 1px #ccc;
      }
  </style>
  <script src="<?php echo e(asset('js_admin/nav.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('copy'); ?>
oncopy='return false' oncut='return false' onpaste='return false'
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrump'); ?>
    Master User
<?php $__env->stopSection(); ?>
<?php $__env->startSection('isi'); ?>
  <div class="isi">
    <table>
      <caption>Tabel User</caption>
      <thead>
        <tr>
          <th scope="col">Nama User</th>
          <th scope="col">Posisi</th>
          <th scope="col">Desa</th>
          <th scope="col">Email</th>
          <th scope="col">Status</th>
        </tr>
      </thead>
      <?php if($count != 0): ?>
        <tbody>
          <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $us): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr id="<?php echo e($us->id); ?>" class="table">
            <td data-label="Nama User" class="titik"><?php echo e($us->nama); ?></td>
            <td data-label="Posisi">
            <?php if($us->roles_id == 1): ?>
                Kecamatan
            <?php elseif($us->roles_id == 2): ?>
                Desa
            <?php else: ?>
                Warga
            <?php endif; ?>
            </td>
            <td data-label="Desa" class="titik"><?php echo e($us->desa); ?></td>
            <td data-label="Email" class="titik"><?php echo e($us->email); ?></td>
            <td data-label="Status">
              <?php if($us->aktivasi == 1): ?>
              OK
              <?php else: ?>
              DISABLED
              <?php endif; ?>
            </td>
            <?php if($us->roles_id == 3): ?>
            
              <div id="contextMenu" class="cm_<?php echo e($us->id); ?>" style="display: none">
                <ul class="dropdown-menu" role="menu" aria-labelledby="dropdownMenu" style="display:block;position:static;margin-bottom:5px;">
                  <li class="edit">
                    <a href="/aktivasi/<?php echo e($us->id); ?>">
                      <?php if($us->aktivasi == 1): ?>
                      DISABLE
                      <?php else: ?>
                      ACTIVATE
                      <?php endif; ?>
                    </a>
                  </li>
                </ul>
              </div>
            <?php endif; ?>
            <?php if($us->roles_id == 2): ?>
            
              <div id="contextMenu" class="cm_<?php echo e($us->id); ?>" style="display: none">
                <ul class="dropdown-menu" role="menu" aria-labelledby="dropdownMenu" style="display:block;position:static;margin-bottom:5px;">
                  <li class="edit">
                    <a href="/reset/<?php echo e($us->id); ?>">RESET</a>
                  </li>
                  <li class="detail">
                    <a href="#popup_d<?php echo e($us->id); ?>">DETAIL</a>
                  </li>
                </ul>
              </div>
            <?php endif; ?>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      <?php else: ?>
        <tbody>
          <tr>Belum ada data! Tambah sekarang...</tr>
        </tbody>
      <?php endif; ?>
    </table>
    <div class="pagination">
        <a style="color:white;" class="add" href="#add">Tambah</a>
        <?php
          // config
          $link_limit = 5;
          ?>

          <?php if($data->lastPage() > 1): ?>
              <ul>
                  <li class="<?php echo e(($data->currentPage() == 1) ? ' disabled' : ''); ?>">
                      <a href="<?php echo e($data->url(1)); ?>">First</a>
                  </li>
                  <?php for($i = 1; $i <= $data->lastPage(); $i++): ?>
                      <?php
                      $half_total_links = floor($link_limit / 2);
                      $from = $data->currentPage() - $half_total_links;
                      $to = $data->currentPage() + $half_total_links;
                      if ($data->currentPage() < $half_total_links) {
                        $to += $half_total_links - $data->currentPage();
                      }
                      if ($data->lastPage() - $data->currentPage() < $half_total_links) {
                          $from -= $half_total_links - ($data->lastPage() - $data->currentPage()) - 1;
                      }
                      ?>
                      <?php if($from < $i && $i < $to): ?>
                          <li class="<?php echo e(($data->currentPage() == $i) ? ' active' : ''); ?>">
                              <a href="<?php echo e($data->url($i)); ?>"><?php echo e($i); ?></a>
                          </li>
                      <?php endif; ?>
                  <?php endfor; ?>
                  <li class="<?php echo e(($data->currentPage() == $data->lastPage()) ? ' disabled' : ''); ?>">
                      <a href="<?php echo e($data->url($data->lastPage())); ?>">Last</a>
                  </li>
              </ul>
          <?php endif; ?>
    </div>
  </div>
  <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $us): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
    <div id="popup_d<?php echo e($us->id); ?>" class="overlay">
      <div class="popup">
        <a class="close" href="#">&times;</a>
        <h2>DETAIL DATA</h2>
        <div class="content" style="text-align: center">
          <h4>Nama : <?php echo e($us->nama); ?></h4>
          <h4>Email : <?php echo e($us->email); ?></h4>
          <?php if(Hash::check('rahasia', $us->password)): ?>
          <h4>Password : <span style="background: yellow;"> rahasia </span></h4>
          <?php endif; ?>
        </div>
      </div>
    </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  
  <div id="add" class="overlay">
    <div class="popup">
      <h2>Form Tambah Data</h2>
      <div class="content">
        <form id="form" action="/master_user_tambah" method="post">
          <?php echo e(csrf_field()); ?>

          <input type="reset" id="configreset" value="&times;" class="close" onclick="href();">
          <fieldset>
            <input placeholder="Nama User" autocomplete="off" type="text" name="nama" value="<?php echo e(old('nama')); ?>" tabindex="1" required oninvalid="this.setCustomValidity('Data tidak boleh kosong')" oninput="setCustomValidity('')" autofocus>
            <?php if ($errors->has('nama')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nama'); ?>
            <div class="invalid-feedback">
                <?php echo e($message); ?>

            </div>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
          </fieldset>
          <fieldset>
            <input placeholder="Email" autocomplete="off" type="email" name="email" value="<?php echo e(old('email')); ?>" tabindex="2" required oninvalid="this.setCustomValidity('Data tidak boleh kosong')" oninput="setCustomValidity('')">
            <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
            <div class="invalid-feedback">
                <?php echo e($message); ?>

            </div>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
          </fieldset>         
          <fieldset>
            <button name="submit" type="submit" id="contact-submit" data-submit="...Sending">Simpan</button>
          </fieldset>
          <fieldset>
            <a id="cancel" href="/master_user">Cancel</a>
          </fieldset>
      </form>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
      function href() {
        window.location.href = '#';
      }
    </script>
    <script src="<?php echo e(asset('js_admin/action.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('super.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\TA\projek\program\master\resources\views/super/master/master_user.blade.php ENDPATH**/ ?>