<?php $__env->startSection('title','OBJEK PETA'); ?>

<?php $__env->startSection('head'); ?>
  <link rel="stylesheet" href="<?php echo e(asset('style_admin/table.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('style_admin/form.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('style_admin/action.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('style_admin/alert.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('style_admin/button.css')); ?>">
  <script src="<?php echo e(asset('js_admin/nav.js')); ?>"></script>
  <script src="<?php echo e(asset('jquery/jquery.js')); ?>"></script>
  <link rel="stylesheet" href="https://unpkg.com/leaflet@1.6.0/dist/leaflet.css"
  integrity="sha512-xwE/Az9zrjBIphAcBb3F6JVqxf46+CDLwfLMHloNu6KEQCAWi6HcDUbeOfBIptF7tcCzusKFjFw2yuvEpDL9wQ=="
  crossorigin=""/>
  <script src="https://unpkg.com/leaflet@1.6.0/dist/leaflet.js"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('copy'); ?>
oncopy='return false' oncut='return false' onpaste='return false'
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrump'); ?>
    <?php if(Auth::user()->roles_id != 2): ?>
        Objek Peta
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('isi'); ?>
  <div class="isi">
    <table>
      <caption>Tabel Objek Peta</caption>
      <thead>
        <tr>
          <th scope="col">Nama</th>
          <th scope="col">Kategori</th>
          <th scope="col">Foto</th>
        </tr>
      </thead>
      <?php if($count != 0): ?>
        <tbody>
          <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr id="<?php echo e($pt->id); ?>" class="table">
              <td data-label="Nama"><?php echo e($pt->nama); ?></td>
              <td data-label="Kategori"><?php echo e($pt->tipe); ?></td>
              <td data-label="Foto"><a href="/gambar/objek/ori/<?php echo e($pt->foto1); ?>"><img src="/gambar/objek/thumbnail/<?php echo e($pt->foto1); ?>" alt="" width="80px" height="auto"></a></td>
                
                <div id="contextMenu" class="cm_<?php echo e($pt->id); ?>" style="display: none">
                  <ul class="dropdown-menu" role="menu" aria-labelledby="dropdownMenu" style="display:block;position:static;margin-bottom:5px;">
                    <li class="edit">
                      <a href="#popup_e<?php echo e($pt->id); ?>">EDIT</a>
                    </li>
                    <li class="hapus">
                      <a href="#popup_h<?php echo e($pt->id); ?>" >HAPUS</a>
                    </li>
                  </ul>
                </div>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      <?php else: ?>
        <tbody>
          <tr>Data masih kosong! tambah sekarang...</tr>
        </tbody>
      <?php endif; ?>
    </table>
    <div class="pagination">
        <a style="color:white;" class="add" href="#add">Tambah</a>
        <a style="right: 0; width: 50px;" href="/maps"><i style="width: 28px; height: 28px; color: mediumseagreen;" class="fa fa-globe fa-2x"></i></a>
        <?php
          // config
          $link_limit = 5;
          ?>

          <?php if($data->lastPage() > 1): ?>
              <ul>
                  <li class="<?php echo e(($data->currentPage() == 1) ? ' disabled' : ''); ?>">
                      <a href="<?php echo e($data->url(1)); ?>">First</a>
                  </li>
                  <?php for($i = 1; $i <= $data->lastPage(); $i++): ?>
                      <?php
                      $half_total_links = floor($link_limit / 2);
                      $from = $data->currentPage() - $half_total_links;
                      $to = $data->currentPage() + $half_total_links;
                      if ($data->currentPage() < $half_total_links) {
                        $to += $half_total_links - $data->currentPage();
                      }
                      if ($data->lastPage() - $data->currentPage() < $half_total_links) {
                          $from -= $half_total_links - ($data->lastPage() - $data->currentPage()) - 1;
                      }
                      ?>
                      <?php if($from < $i && $i < $to): ?>
                          <li class="<?php echo e(($data->currentPage() == $i) ? ' active' : ''); ?>">
                              <a href="<?php echo e($data->url($i)); ?>"><?php echo e($i); ?></a>
                          </li>
                      <?php endif; ?>
                  <?php endfor; ?>
                  <li class="<?php echo e(($data->currentPage() == $data->lastPage()) ? ' disabled' : ''); ?>">
                      <a href="<?php echo e($data->url($data->lastPage())); ?>">Last</a>
                  </li>
              </ul>
          <?php endif; ?>
    </div>
  </div>
  <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
    <div id="popup_e<?php echo e($pt->id); ?>" class="overlay">
      <div class="popup">
        <h2>Edit Desa</h2>
        <div class="content">
          <form id="form" action="/objek_peta_ubah/<?php echo e($pt->id); ?>" method="post" enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>

            <input type="reset" id="configreset" value="&times;" class="close" onclick="href();">
            <fieldset>
              <input placeholder="Nama Kerusakan" type="text" autocomplete="off" name="nama" value="<?php echo e(old('nama') ?? $pt->nama); ?>" tabindex="1" required oninvalid="this.setCustomValidity('Data tidak boleh kosong')" oninput="setCustomValidity('')" autofocus>
              <?php if ($errors->has('nama')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nama'); ?>
              <div class="invalid-feedback">
                  <?php echo e($message); ?>

              </div>
              <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?> 
            </fieldset>
            <fieldset>
              <select name="kategori" id="">
                <option disabled 
                <?php if($pt->types_id == ''): ?>
                    selected
                <?php endif; ?>
                >--Pilih Kategori--</option>
                <?php $__currentLoopData = $tipe; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($item->id); ?>"
                  <?php if(old('kategori') == ''): ?>
                    <?php if($pt->types_id == $item->id): ?>
                        selected
                    <?php endif; ?>
                  <?php elseif(old('kategori') == $item->id): ?>  
                      selected
                  <?php endif; ?>
                  ><?php echo e($item->nama); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
              <?php if ($errors->has('kategori')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('kategori'); ?>
              <div class="invalid-feedback">
                  <?php echo e($message); ?>

              </div>
              <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?> 
            </fieldset>
            <fieldset>
              <input style="margin-top: 10px" type="file" id="fileimg1" accept="image/*" name="foto1">
              <img style="margin-left: 20px" src="/gambar/objek/thumbnail/<?php echo e($pt->foto1); ?>" alt="">
              <?php if ($errors->has('foto1')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('foto1'); ?>
              <div class="invalid-feedback">
                  <?php echo e($message); ?>

              </div>
              <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?> 
            </fieldset>
            <fieldset>
              <input id="bujur<?php echo e($pt->id); ?>" placeholder="Longitude" type="text" name="bujur" value="<?php echo e(old('bujur') ?? $pt->bujur); ?>" required oninvalid="this.setCustomValidity('Data tidak boleh kosong')" oninput="setCustomValidity('')" readonly>
              <?php if ($errors->has('bujur')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('bujur'); ?>
              <div class="invalid-feedback">
                  <?php echo e($message); ?>

              </div>
              <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </fieldset>
            <fieldset>
              <input id="lintang<?php echo e($pt->id); ?>" placeholder="Latitude" type="text" name="lintang" value="<?php echo e(old('lintang') ?? $pt->lintang); ?>" required oninvalid="this.setCustomValidity('Data tidak boleh kosong')" oninput="setCustomValidity('')" readonly>
              <?php if ($errors->has('lintang')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('lintang'); ?>
              <div class="invalid-feedback">
                  <?php echo e($message); ?>

              </div>
              <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </fieldset>
            <fieldset>
            <div onmousemove="getcenter2(<?php echo e($pt->id); ?>);" class="map" id="mapid<?php echo e($pt->id); ?>" style="width: 100%; height: 40vh;">
                <img class="marker" src="<?php echo e(asset('gambar/marker/marker.png')); ?>" alt="">
              </div>
            <fieldset>
            <fieldset>
              <button name="submit" type="submit" id="contact-submit" data-submit="...Sending">Simpan</button>
            </fieldset>
        </form>
        </div>
      </div>
    </div>
    
    <div id="popup_h<?php echo e($pt->id); ?>" class="overlay">
      <div class="popup">
        <h2>Hapus Objek Peta?</h2>
        <div class="content">
          <fieldset class="acc">
            <a class="acc" href="/objek_peta_hapus/<?php echo e($pt->id); ?>">HAPUS</a>
            <a class="cancel" href="#">Batal</a>
          </fieldset>
        </div>
      </div>
    </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <div id="add" class="overlay">
    <div class="popup">
      <h2>Tambah Data</h2>
      <div class="content">
        <form id="form" action="/objek_peta_tambah" method="post" enctype="multipart/form-data">
          <?php echo e(csrf_field()); ?>

          <input type="reset" id="configreset" value="&times;" class="close" onclick="href();">
          <fieldset>
            <input placeholder="Nama Objek" type="text" autocomplete="off" name="nama" value="<?php echo e(old('nama')); ?>" tabindex="1" required oninvalid="this.setCustomValidity('Data tidak boleh kosong')" oninput="setCustomValidity('')" autofocus>
            <?php if ($errors->has('nama')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nama'); ?>
            <div class="invalid-feedback">
                <?php echo e($message); ?>

            </div>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?> 
          </fieldset>
          <fieldset>
            <select name="kategori" id="">
              <option disabled 
                <?php if(old('kategori') == ''): ?>
                    selected
                <?php endif; ?> value="">--Pilih Kategori--</option>
              <?php $__currentLoopData = $tipe; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option
                <?php if(old('kategori') == '$item->id'): ?>
                    selected
                <?php endif; ?>
                value="<?php echo e($item->id); ?>"><?php echo e($item->nama); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php if ($errors->has('kategori')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('kategori'); ?>
            <div class="invalid-feedback">
                <?php echo e($message); ?>

            </div>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?> 
          </fieldset>
          <fieldset>
            <input style="margin-top: 10px" type="file" id="fileimg1" accept="image/*" name="foto1">
            <?php if ($errors->has('foto1')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('foto1'); ?>
            <div class="invalid-feedback">
                <?php echo e($message); ?>

            </div>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?> 
          </fieldset>
          <fieldset>
            <input id="bujur" placeholder="Longitude" type="text" name="bujur" value="<?php echo e(old('bujur')); ?>" required oninvalid="this.setCustomValidity('Data tidak boleh kosong')" oninput="setCustomValidity('')" readonly>
            <?php if ($errors->has('bujur')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('bujur'); ?>
            <div class="invalid-feedback">
                <?php echo e($message); ?>

            </div>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
          </fieldset>
          <fieldset>
            <input id="lintang" placeholder="Latitude" type="text" name="lintang" value="<?php echo e(old('lintang')); ?>" required oninvalid="this.setCustomValidity('Data tidak boleh kosong')" oninput="setCustomValidity('')" readonly>
            <?php if ($errors->has('lintang')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('lintang'); ?>
            <div class="invalid-feedback">
                <?php echo e($message); ?>

            </div>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
          </fieldset>
          <fieldset>
            <div onmousemove="getcenter1();" id="mapid" style="width: 100%; height: 35vh;">
              <img class="marker" src="<?php echo e(asset('gambar/marker/marker.png')); ?>" alt="">
            </div>
          </fieldset>
          <fieldset>
            <button name="submit" type="submit" id="contact-submit" data-submit="...Sending">Simpan</button>
          </fieldset>
      </form>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
      function href() {
        window.location.href = '#';
      }
    </script>
    <script src="<?php echo e(asset('js_admin/action.js')); ?>"></script>
    <script src="<?php echo e(asset('js_admin/bundle.js')); ?>"></script>
    <script src="<?php echo e(asset('js_admin/polygon.js')); ?>"></script>
    <script src="<?php echo e(asset('js_admin/crud_map.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('super.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\TA\projek\program\master\resources\views/super/objek/objek_peta.blade.php ENDPATH**/ ?>