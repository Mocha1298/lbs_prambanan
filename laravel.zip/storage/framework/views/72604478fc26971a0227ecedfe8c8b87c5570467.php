<?php $__env->startSection('title','OBJEK KERUSAKAN'); ?>

<?php $__env->startSection('head'); ?>
  
  <link rel="stylesheet" href="<?php echo e(asset('style_admin/table.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('style_admin/form.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('style_admin/action.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('style_admin/alert.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('style_admin/button.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('style_user/box-map.css')); ?>">
  <script src="<?php echo e(asset('js_admin/nav.js')); ?>"></script>
  <script src="<?php echo e(asset('jquery/jquery.js')); ?>"></script>
  <style>
    #peta{
      width: 100%;
      height: 500px;
    }
  </style>
  <link rel="stylesheet" href="https://unpkg.com/leaflet@1.6.0/dist/leaflet.css"
  integrity="sha512-xwE/Az9zrjBIphAcBb3F6JVqxf46+CDLwfLMHloNu6KEQCAWi6HcDUbeOfBIptF7tcCzusKFjFw2yuvEpDL9wQ=="
  crossorigin=""/>
  <script src="https://unpkg.com/leaflet@1.6.0/dist/leaflet.js"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('copy'); ?>
oncopy='return false' oncut='return false' onpaste='return false'
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrump'); ?>
    <?php if(Auth::user()->roles_id != 2): ?>
        <a href="/master_kecamatan"><?php echo e($kc->nama); ?></a> > <a href="/master_desa/<?php echo e($ids); ?>"><?php echo e($vil->nama); ?></a> > Data Kerusakan
    <?php else: ?>
    Data Kerusakan
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('isi'); ?>
  <div class="isi">
    <table>
      <caption>Tabel Kerusakan</caption>
      <a style="right: 0; width: 50px;" href="#map"><i style="width: 28px; height: 28px; color: mediumseagreen;" class="fa fa-globe fa-2x"></i></a>
      <thead>
        <tr>
          <th scope="col">Nama</th>
          <th scope="col">Sumber</th>
          <th scope="col">Level</th>
          <th scope="col">Status</th>
          <th scope="col">Tanggal</th>
          <th scope="col">RT/RW</th>
          <th scope="col">Foto</th>
        </tr>
      </thead>
      <?php if($count != 0): ?>
        <tbody>
          <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr id="<?php echo e($kr->id); ?>" class="table">
              <td data-label="Nama" class="titik"><?php echo e($kr->nama); ?></td>
              <td data-label="Sumber"><?php if($kr->sumber == 1): ?> RPJMD <?php else: ?> SUARA WARGA <?php endif; ?></td>
              <td data-label="Level"><?php echo e($kr->level); ?></td>
              <td data-label="Status"><?php echo e($kr->status); ?></td>
              <td data-label="Tanggal"><?php echo e($kr->perbaikan); ?></td>
              <td data-label="RT/RW"><?php echo e($kr->rt); ?>/<?php echo e($kr->rw); ?></td>
              <td data-label="Foto">
                <?php if($kr->status == 'Rencana'): ?>
                <a href="/gambar/kerusakan/ori/<?php echo e($kr->foto1); ?>"><img src="/gambar/kerusakan/thumbnail/<?php echo e($kr->foto1); ?>" alt="" width="50px" height="auto"></a>
                <?php elseif($kr->status == 'Sedang'): ?>
                <a href="/gambar/kerusakan/ori/<?php echo e($kr->foto1); ?>"><img src="/gambar/kerusakan/thumbnail/<?php echo e($kr->foto1); ?>" alt="" width="50px" height="auto"></a>
                <a href="/gambar/kerusakan/ori/<?php echo e($kr->foto2); ?>"><img src="/gambar/kerusakan/thumbnail/<?php echo e($kr->foto2); ?>" alt="" width="50px" height="auto"></a>
                <?php elseif($kr->status == 'Selesai'): ?>
                <a href="/gambar/kerusakan/ori/<?php echo e($kr->foto1); ?>"><img src="/gambar/kerusakan/thumbnail/<?php echo e($kr->foto1); ?>" alt="" width="50px" height="auto"></a>
                <a href="/gambar/kerusakan/ori/<?php echo e($kr->foto2); ?>"><img src="/gambar/kerusakan/thumbnail/<?php echo e($kr->foto2); ?>" alt="" width="50px" height="auto"></a>
                <a href="/gambar/kerusakan/ori/<?php echo e($kr->foto3); ?>"><img src="/gambar/kerusakan/thumbnail/<?php echo e($kr->foto3); ?>" alt="" width="50px" height="auto"></a>
                <?php endif; ?>
              </td>
                
                <div id="contextMenu" class="cm_<?php echo e($kr->id); ?>" style="display: none">
                  <ul class="dropdown-menu" role="menu" aria-labelledby="dropdownMenu" style="display:block;position:static;margin-bottom:5px;">
                    <li class="edit">
                      <a href="#popup_e<?php echo e($kr->id); ?>">EDIT</a>
                    </li>
                    <li class="hapus">
                      <a href="#popup_h<?php echo e($kr->id); ?>" >HAPUS</a>
                    </li>
                    <li class="detail">
                      <a href="#popup_s<?php echo e($kr->id); ?>">STATUS</a>
                    </li>
                  </ul>
                </div>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      <?php else: ?>
        <tbody>
          <tr>Data masih kosong! tambah sekarang...</tr>
        </tbody>
      <?php endif; ?>
    </table>
    <div class="pagination">
        <a style="color:white;" class="add" href="#add">Tambah</a>
        <?php
          // config
          $link_limit = 5;
          ?>

          <?php if($data->lastPage() > 1): ?>
              <ul>
                  <li class="<?php echo e(($data->currentPage() == 1) ? ' disabled' : ''); ?>">
                      <a href="<?php echo e($data->url(1)); ?>">First</a>
                  </li>
                  <?php for($i = 1; $i <= $data->lastPage(); $i++): ?>
                      <?php
                      $half_total_links = floor($link_limit / 2);
                      $from = $data->currentPage() - $half_total_links;
                      $to = $data->currentPage() + $half_total_links;
                      if ($data->currentPage() < $half_total_links) {
                        $to += $half_total_links - $data->currentPage();
                      }
                      if ($data->lastPage() - $data->currentPage() < $half_total_links) {
                          $from -= $half_total_links - ($data->lastPage() - $data->currentPage()) - 1;
                      }
                      ?>
                      <?php if($from < $i && $i < $to): ?>
                          <li class="<?php echo e(($data->currentPage() == $i) ? ' active' : ''); ?>">
                              <a href="<?php echo e($data->url($i)); ?>"><?php echo e($i); ?></a>
                          </li>
                      <?php endif; ?>
                  <?php endfor; ?>
                  <li class="<?php echo e(($data->currentPage() == $data->lastPage()) ? ' disabled' : ''); ?>">
                      <a href="<?php echo e($data->url($data->lastPage())); ?>">Last</a>
                  </li>
              </ul>
          <?php endif; ?>
    </div>
  </div>
  <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
    <div id="popup_e<?php echo e($kr->id); ?>" class="overlay">
      <div class="popup">
        <h2>Edit Desa</h2>
        <div class="content">
          <form id="form" action="/objek_kerusakan_ubah/<?php echo e($kr->id); ?>" method="post" enctype="multipart/form-data">
            <input type="reset" id="configreset" value="&times;" class="close" onclick="href();">
            <?php echo e(csrf_field()); ?>

            <fieldset>
              <input placeholder="Nama Kerusakan" type="text" autocomplete="off" name="nama" value="<?php echo e(old('nama') ?? $kr->nama); ?>" tabindex="1" required oninvalid="this.setCustomValidity('Data tidak boleh kosong')" oninput="setCustomValidity('')" autofocus>
              <?php if ($errors->has('nama')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nama'); ?>
              <div class="invalid-feedback">
                  <?php echo e($message); ?>

              </div>
              <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?> 
            </fieldset>
            <fieldset>
              <input placeholder="RT" type="text" autocomplete="off" name="rt" value="<?php echo e(old('rt') ?? $kr->rt); ?>" tabindex="1" required oninvalid="this.setCustomValidity('Data tidak boleh kosong')" oninput="setCustomValidity('')" autofocus>
              <?php if ($errors->has('rt')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('rt'); ?>
              <div class="invalid-feedback">
                  <?php echo e($message); ?>

              </div>
              <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?> 
            </fieldset>
            <fieldset>
              <input placeholder="RW" type="text" autocomplete="off" name="rw" value="<?php echo e(old('rw') ?? $kr->rw); ?>" tabindex="1" required oninvalid="this.setCustomValidity('Data tidak boleh kosong')" oninput="setCustomValidity('')" autofocus>
              <?php if ($errors->has('rw')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('rw'); ?>
              <div class="invalid-feedback">
                  <?php echo e($message); ?>

              </div>
              <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?> 
            </fieldset>
            <fieldset>
              <select name="level" id="form" tabindex="2" required>
                <option <?php if(old('level')==''): ?> selected <?php endif; ?> value="">-- PILIH LEVEL--</option>
                <option <?php if(old('level')=='Ringan' || $kr->level == 'Ringan'): ?> selected <?php endif; ?> value="Ringan">Ringan</option>
                <option <?php if(old('level')=='Berat' || $kr->level == 'Berat'): ?> selected <?php endif; ?> value="Berat">Berat</option>
              </select>
              <?php if ($errors->has('level')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('level'); ?>
              <div class="invalid-feedback">
                  <?php echo e($message); ?>

              </div>
              <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </fieldset>
            <fieldset>
              <input type="date" autocomplete="off" name="perbaikan" value="<?php echo e(old('perbaikan') ?? $kr->perbaikan); ?>" tabindex="3" required oninvalid="this.setCustomValidity('Data tidak boleh kosong')" oninput="setCustomValidity('')">
              <label style="font-size: 12px; color: #888;" for="perbaikan">Rencana Perbaikan</label>
              <?php if ($errors->has('perbaikan')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('perbaikan'); ?>
              <div class="invalid-feedback">
                  <?php echo e($message); ?>

              </div>
              <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </fieldset>
              <?php if($kr->status == 'Rencana'): ?>
              <fieldset>
                <label for="">Foto Kerusakan</label>
                <input style="margin-top: 10px" type="file" id="fileimg1" accept="image/*" name="foto1">
                <img style="margin-left: 20px" width="50px" height="auto" src="/gambar/kerusakan/thumbnail/<?php echo e($kr->foto1); ?>" alt="">
                <?php if ($errors->has('foto1')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('foto1'); ?>
                <div class="invalid-feedback">
                    <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
              </fieldset>
              <?php endif; ?>
              <?php if($kr->status == 'Sedang'): ?>
              <fieldset>
                <label for="">Foto Kerusakan</label>
                <input style="margin-top: 10px" type="file" id="fileimg1" accept="image/*" name="foto1">
                <img style="margin-left: 20px" width="50px" height="auto" src="/gambar/kerusakan/thumbnail/<?php echo e($kr->foto1); ?>" alt="">  
                <?php if ($errors->has('foto1')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('foto1'); ?>
                <div class="invalid-feedback">
                    <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
              </fieldset>
              <fieldset>
                <label for="">Foto Perbaikan</label>
                <input style="margin-top: 10px" type="file" id="fileimg1" accept="image/*" name="foto2">
                <img style="margin-left: 20px" width="50px" height="auto" src="/gambar/kerusakan/thumbnail/<?php echo e($kr->foto2); ?>" alt="">
                <?php if ($errors->has('foto2')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('foto2'); ?>
                <div class="invalid-feedback">
                    <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
              </fieldset>
              <?php endif; ?>
              <?php if($kr->status == 'Selesai'): ?>
              <fieldset>
                <label for="">Foto Kerusakan</label>
                <input style="margin-top: 10px" type="file" id="fileimg1" accept="image/*" name="foto1">
                <img style="margin-left: 20px" width="50px" height="auto" src="/gambar/kerusakan/thumbnail/<?php echo e($kr->foto1); ?>" alt="">
                <?php if ($errors->has('foto1')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('foto1'); ?>
                <div class="invalid-feedback">
                    <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
              </fieldset>
              <fieldset>
                <label for="">Foto Perbaikan</label>
                <input style="margin-top: 10px" type="file" id="fileimg1" accept="image/*" name="foto2">
                <img style="margin-left: 20px" width="50px" height="auto" src="/gambar/kerusakan/thumbnail/<?php echo e($kr->foto2); ?>" alt="">
                <?php if ($errors->has('foto2')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('foto2'); ?>
                <div class="invalid-feedback">
                    <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
              </fieldset>
              <fieldset>
                <label for="">Foto Selesai</label>
                <input style="margin-top: 10px" type="file" id="fileimg1" accept="image/*" name="foto3">
                <img style="margin-left: 20px" width="50px" height="auto" src="/gambar/kerusakan/thumbnail/<?php echo e($kr->foto3); ?>" alt="">
                <?php if ($errors->has('foto3')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('foto3'); ?>
                <div class="invalid-feedback">
                    <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
              </fieldset>
              <?php endif; ?>
            <fieldset>
              <input id="bujur<?php echo e($kr->id); ?>" placeholder="Longitude" type="text" name="bujur" value="<?php echo e(old('bujur') ?? $kr->bujur); ?>" required oninvalid="this.setCustomValidity('Data tidak boleh kosong')" oninput="setCustomValidity('')" readonly>
              <?php if ($errors->has('bujur')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('bujur'); ?>
              <div class="invalid-feedback">
                  <?php echo e($message); ?>

              </div>
              <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </fieldset>
            <fieldset>
              <input id="lintang<?php echo e($kr->id); ?>" placeholder="Latitude" type="text" name="lintang" value="<?php echo e(old('lintang') ?? $kr->lintang); ?>" required oninvalid="this.setCustomValidity('Data tidak boleh kosong')" oninput="setCustomValidity('')" readonly>
              <?php if ($errors->has('lintang')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('lintang'); ?>
              <div class="invalid-feedback">
                  <?php echo e($message); ?>

              </div>
              <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </fieldset>
            <fieldset>
            <div onmousemove="getcenter2(<?php echo e($kr->id); ?>);" class="map" id="mapid<?php echo e($kr->id); ?>" style="width: 100%; height: 40vh;">
                <img class="marker" src="<?php echo e(asset('gambar/marker/marker.png')); ?>" alt="">
              </div>
            <fieldset>
            <fieldset>
              <button name="submit" type="submit" id="contact-submit" data-submit="...Sending">Simpan</button>
            </fieldset>
            <fieldset>
              <a id="cancel" href="/objek_kerusakan/<?php echo e($id); ?>">Cancel</a>
            </fieldset>
        </form>
        </div>
      </div>
    </div>
    
    <div id="popup_h<?php echo e($kr->id); ?>" class="overlay">
      <div class="popup">
        <h2>Hapus Data Kerusakan?</h2>
        <div class="content">
          <fieldset class="acc">
            <a class="acc" href="/objek_kerusakan_hapus/<?php echo e($kr->id); ?>">HAPUS</a>
            <a class="cancel" href="#">Batal</a>
          </fieldset>
        </div>
      </div>
    </div>
    
    <div id="popup_s<?php echo e($kr->id); ?>" class="overlay">
      <div class="popup">
        <h2>Ubah Status Perbaikan</h2>
        <div class="content">
          <form method="post" id="form" action="/objek_kerusakan_status/<?php echo e($kr->id); ?>">
            <?php echo e(csrf_field()); ?>

            <input type="reset" id="configreset" value="&times;" class="close" onclick="href();">
            <fieldset>
              <select name="kategori" id="form">
                <?php $__currentLoopData = $tipe; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($item->id); ?>"
                  <?php if(old('kategori') == ''): ?>
                    <?php if($kr->types_id == $item->id): ?>
                        selected
                    <?php endif; ?>
                  <?php elseif(old('kategori') == $item->id): ?>  
                      selected
                  <?php endif; ?>
                  ><?php echo e($item->nama); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </fieldset>
            <fieldset>
              <button name="submit" type="submit" id="contact-submit" data-submit="...Sending">Simpan</button>
            </fieldset>
            <fieldset>
              <a id="cancel" href="/objek_kerusakan/<?php echo e($id); ?>">Cancel</a>
            </fieldset>
          </form>
        </div>
      </div>
    </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <div id="add" class="overlay">
    <div class="popup">
      <h2>Tambah Data</h2>
      <div class="content">
        <form id="form" action="/objek_kerusakan_tambah/<?php echo e($id); ?>" method="post" enctype="multipart/form-data">
          <?php echo e(csrf_field()); ?>

          <input type="reset" id="configreset" value="&times;" class="close" onclick="href();">
          
          <fieldset>
            <input placeholder="Nama Kerusakan" type="text" autocomplete="off" name="nama" value="<?php echo e(old('nama')); ?>" tabindex="1" required oninvalid="this.setCustomValidity('Data tidak boleh kosong')" oninput="setCustomValidity('')" autofocus>
            <?php if ($errors->has('nama')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nama'); ?>
            <div class="invalid-feedback">
                <?php echo e($message); ?>

            </div>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?> 
          </fieldset>
          <fieldset>
            <input placeholder="RT" type="text" autocomplete="off" name="rt" value="<?php echo e(old('rt')); ?>" tabindex="1" required oninvalid="this.setCustomValidity('Data tidak boleh kosong')" oninput="setCustomValidity('')" autofocus>
            <?php if ($errors->has('rt')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('rt'); ?>
            <div class="invalid-feedback">
                <?php echo e($message); ?>

            </div>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?> 
          </fieldset>
          <fieldset>
            <input placeholder="RW" type="text" autocomplete="off" name="rw" value="<?php echo e(old('rw')); ?>" tabindex="1" required oninvalid="this.setCustomValidity('Data tidak boleh kosong')" oninput="setCustomValidity('')" autofocus>
            <?php if ($errors->has('rw')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('rw'); ?>
            <div class="invalid-feedback">
                <?php echo e($message); ?>

            </div>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?> 
          </fieldset>
          <fieldset>
            <select name="level" id="form" tabindex="2" required>
              <option <?php if(old('level')==''): ?> selected <?php endif; ?> value="">-- PILIH LEVEL--</option>
              <option <?php if(old('level')=='Ringan'): ?> selected <?php endif; ?> value="Ringan">Ringan</option>
              <option <?php if(old('level')=='Berat'): ?> selected <?php endif; ?> value="Berat">Berat</option>
            </select>
            <?php if ($errors->has('level')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('level'); ?>
            <div class="invalid-feedback">
                <?php echo e($message); ?>

            </div>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
          </fieldset>
          <fieldset>
            <input placeholder="Rencana Perbaikan" type="date" autocomplete="off" name="perbaikan" value="<?php echo e(old('perbaikan')); ?>" tabindex="5" required oninvalid="this.setCustomValidity('Data tidak boleh kosong')" oninput="setCustomValidity('')">
            <label style="font-size: 12px; color: #888;" for="perbaikan">Rencana Perbaikan</label>
            <?php if ($errors->has('perbaikan')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('perbaikan'); ?>
            <div class="invalid-feedback">
                <?php echo e($message); ?>

            </div>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
          </fieldset>
          <fieldset>
            <input style="margin-top: 10px" type="file" id="fileimg1" accept="image/*" name="foto1">
          </fieldset>
          <fieldset>
            <input id="bujur" placeholder="Longitude" type="text" name="bujur" value="<?php echo e(old('bujur')); ?>" required oninvalid="this.setCustomValidity('Data tidak boleh kosong')" oninput="setCustomValidity('')" readonly>
            <?php if ($errors->has('bujur')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('bujur'); ?>
            <div class="invalid-feedback">
                <?php echo e($message); ?>

            </div>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
          </fieldset>
          <fieldset>
            <input id="lintang" placeholder="Latitude" type="text" name="lintang" value="<?php echo e(old('lintang')); ?>" required oninvalid="this.setCustomValidity('Data tidak boleh kosong')" oninput="setCustomValidity('')" readonly>
            <?php if ($errors->has('lintang')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('lintang'); ?>
            <div class="invalid-feedback">
                <?php echo e($message); ?>

            </div>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
          </fieldset>
          <fieldset>
            <div onmousemove="getcenter1();" id="mapid" style="width: 100%; height: 35vh;">
              <img class="marker" src="<?php echo e(asset('gambar/marker/marker.png')); ?>" alt="">
            </div>
          </fieldset>
          <fieldset>
            <button name="submit" type="submit" id="contact-submit" data-submit="...Sending">Simpan</button>
          </fieldset>
          <fieldset>
            <a id="cancel" href="/objek_kerusakan/<?php echo e($id); ?>">Cancel</a>
          </fieldset>
      </form>
      </div>
    </div>
  </div>
  <div id="map" class="overlay">
    <div class="popup">
      <h2>Peta Agenda</h2>
      <a href="#" class="close">&times;</a>
      <div class="content">
        <div id="peta"></div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
      function href() {
        window.location.href = '#';
      }
    </script>
    <script src="<?php echo e(asset('js_admin/action.js')); ?>"></script>
    <script src="<?php echo e(asset('js_admin/bundle.js')); ?>"></script>
    <script src="<?php echo e(asset('js_admin/ajax.js')); ?>"></script>
    <script src="<?php echo e(asset('js_admin/crud_map.js')); ?>"></script>
    <script>
      var peta;
      $.getJSON("/center_kr", function (data){
          peta = L.map('peta',{
              center :  [data.lintang,data.bujur],
              watch : true,
              zoom: 16,
              // scrollWheelZoom: false,
              closePopupOnClick: false
          });
          var geojsonLayer = new L.GeoJSON.AJAX("/batas/"+data.batas,{
              fillOpacity : 0,
              color : 'white'
          });       
          geojsonLayer.addTo(peta);
          L.tileLayer('http://{s}.google.com/vt/lyrs=s&x={x}&y={y}&z={z}',{
              minZoom: 10,
              maxZoom: 20,
              subdomains:['mt0','mt1','mt2','mt3']
          }).addTo(peta);
      });
      $.getJSON("/datapeta_kr", function (data1) {
          for (var i = 0; i < data1.length; i++) {
            var name = data1[i].nama;
            L.marker([data1[i].lintang, data1[i].bujur])
            .addTo(peta)
            .bindPopup(
                (info =
                    "<div class='cont'>"
                        +"<div class='box'>"
                            +"<div class='header'>"
                                +"<h2><strong> Nama Laporan : "+name+"</strong></h2>"
                                +"<p>RT/RW : "+data1[i].rt+"/"+data1[i].rw+" </p>"
                            +"</div>"
                            +"<img src='/gambar/kerusakan/thumbnail/"+data1[i].foto1+"' alt=''>"
                        +"</div>"
                    +"</div>"
                    )
            );
          }
      })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('super.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\TA\projek\program\master\resources\views/super/objek/objek_kerusakan.blade.php ENDPATH**/ ?>