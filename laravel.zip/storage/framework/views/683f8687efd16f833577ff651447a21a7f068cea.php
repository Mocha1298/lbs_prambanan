<?php $__env->startSection('title','Master Desa'); ?>

<?php $__env->startSection('head'); ?>
  <link rel="stylesheet" href="<?php echo e(asset('style_admin/table.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('style_admin/form.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('style_admin/action.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('style_admin/alert.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('style_admin/button.css')); ?>">
  <script src="<?php echo e(asset('js_admin/nav.js')); ?>"></script>
  <link rel="stylesheet" href="https://unpkg.com/leaflet@1.6.0/dist/leaflet.css"
  integrity="sha512-xwE/Az9zrjBIphAcBb3F6JVqxf46+CDLwfLMHloNu6KEQCAWi6HcDUbeOfBIptF7tcCzusKFjFw2yuvEpDL9wQ=="
  crossorigin=""/>
  <script src="https://unpkg.com/leaflet@1.6.0/dist/leaflet.js"></script>
  <script src = "https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('copy'); ?>
oncopy='return false' oncut='return false' onpaste='return false'
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrump'); ?>
    <a href="/master_kecamatan"><?php echo e($kc->nama); ?></a> > Master Desa
<?php $__env->stopSection(); ?>
<?php $__env->startSection('isi'); ?>
  <div class="isi">
    <table>
      <caption>Tabel Desa</caption>
      <thead>
        <tr>
          <th scope="col">Nama Desa</th>
          <th scope="col">Jumlah RW</th>
        </tr>
      </thead>
      <?php if($count != 0): ?>
        <tbody>
          <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ds): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr id="<?php echo e($ds->id); ?>" class="table">
              <td data-label="Nama Desa"><?php echo e($ds->nama); ?></td>
              <td data-label="Jumlah RW"><?php echo e($ds->rw); ?></td>
                
                <div id="contextMenu" class="cm_<?php echo e($ds->id); ?>" style="display: none">
                  <ul class="dropdown-menu" role="menu" aria-labelledby="dropdownMenu" style="display:block;position:static;margin-bottom:5px;">
                    <li class="edit">
                      <a href="#popup_e<?php echo e($ds->id); ?>">EDIT</a>
                    </li>
                    <li class="hapus">
                      <a href="#popup_h<?php echo e($ds->id); ?>">HAPUS</a>
                    </li>
                    <li class="detail">
                      <a href="/objek_kerusakan/<?php echo e($ds->id); ?>">KERUSAKAN</a>
                    </li>
                  </ul>
                </div>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      <?php else: ?>
        <tbody>
          <tr>Data masih kosong! tambah sekarang...</tr>
        </tbody>
      <?php endif; ?>
    </table>
    <div class="pagination">
        <?php if($admin == 1): ?>
        <a class="add false" href="#">Tambah Desa</a>
        <?php else: ?>
        <a style="color:white;" class="add" href="#add">Tambah Desa</a>
        <?php endif; ?>
        <?php
          // config
          $link_limit = 10;
          ?>

          <?php if($data->lastPage() > 1): ?>
              <ul>
                  <li class="<?php echo e(($data->currentPage() == 1) ? ' disabled' : ''); ?>">
                      <a href="<?php echo e($data->url(1)); ?>">First</a>
                  </li>
                  <?php for($i = 1; $i <= $data->lastPage(); $i++): ?>
                      <?php
                      $half_total_links = floor($link_limit / 2);
                      $from = $data->currentPage() - $half_total_links;
                      $to = $data->currentPage() + $half_total_links;
                      if ($data->currentPage() < $half_total_links) {
                        $to += $half_total_links - $data->currentPage();
                      }
                      if ($data->lastPage() - $data->currentPage() < $half_total_links) {
                          $from -= $half_total_links - ($data->lastPage() - $data->currentPage()) - 1;
                      }
                      ?>
                      <?php if($from < $i && $i < $to): ?>
                          <li class="<?php echo e(($data->currentPage() == $i) ? ' active' : ''); ?>">
                              <a href="<?php echo e($data->url($i)); ?>"><?php echo e($i); ?></a>
                          </li>
                      <?php endif; ?>
                  <?php endfor; ?>
                  <li class="<?php echo e(($data->currentPage() == $data->lastPage()) ? ' disabled' : ''); ?>">
                      <a href="<?php echo e($data->url($data->lastPage())); ?>">Last</a>
                  </li>
              </ul>
<?php endif; ?>
    </div>
  </div>
  <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ds): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
    <div id="popup_e<?php echo e($ds->id); ?>" class="overlay">
      <div class="popup">
        <h2>Edit Data Desa</h2>
        <div class="content">
          <form id="form" action="/master_desa_ubah/<?php echo e($ds->id); ?>" method="post">
            <?php echo e(csrf_field()); ?>

            <input type="reset" id="configreset" value="&times;" class="close" onclick="href();">
            <input type="text" name="id" value="<?php echo e($id); ?>" hidden>
            <fieldset>
              <input placeholder="Nama Desa" type="text" name="nama" value="<?php echo e(old('nama') ?? $ds->nama); ?>" tabindex="1" required oninvalid="this.setCustomValidity('Data tidak boleh kosong')" oninput="setCustomValidity('')" autofocus>
              <?php if ($errors->has('nama')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nama'); ?>
              <div class="invalid-feedback">
                  <?php echo e($message); ?>

              </div>
              <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </fieldset>
            <fieldset>
              <input placeholder="Jumlah RW" type="text" name="rw" value="<?php echo e(old('rw') ?? $ds->rw); ?>" tabindex="2" required oninvalid="this.setCustomValidity('Data tidak boleh kosong')" oninput="setCustomValidity('')">
              <?php if ($errors->has('rw')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('rw'); ?>
              <div class="invalid-feedback">
                  <?php echo e($message); ?>

              </div>
              <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </fieldset>
            <fieldset>
              <input id="bujur<?php echo e($ds->id); ?>" placeholder="Longitude" type="text" name="bujur" value="<?php echo e(old('bujur') ?? $ds->bujur); ?>" required oninvalid="this.setCustomValidity('Data tidak boleh kosong')" oninput="setCustomValidity('')" readonly>
              <?php if ($errors->has('bujur')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('bujur'); ?>
              <div class="invalid-feedback">
                  <?php echo e($message); ?>

              </div>
              <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </fieldset>
            <fieldset>
              <input id="lintang<?php echo e($ds->id); ?>" placeholder="Latitude" type="text" name="lintang" value="<?php echo e(old('lintang') ?? $ds->lintang); ?>" required oninvalid="this.setCustomValidity('Data tidak boleh kosong')" oninput="setCustomValidity('')" readonly>
              <?php if ($errors->has('lintang')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('lintang'); ?>
              <div class="invalid-feedback">
                  <?php echo e($message); ?>

              </div>
              <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </fieldset>
            <fieldset>
            <div onmousemove="getcenter2(<?php echo e($ds->id); ?>);" class="map" id="mapid<?php echo e($ds->id); ?>" style="width: 100%; height: 40vh;">
                <img class="marker" src="<?php echo e(asset('gambar/marker/marker.png')); ?>" alt="">
              </div>
            <fieldset>
            <fieldset>
              <button name="submit" type="submit" id="contact-submit" data-submit="...Sending">Simpan</button>
            </fieldset>
            <fieldset>
              <a id="cancel" href="/master_desa/<?php echo e($id); ?>">Cancel</a>
            </fieldset>
        </form>
        </div>
      </div>
    </div>
    
    <div id="popup_h<?php echo e($ds->id); ?>" class="overlay">
      <div class="popup">
        <h2>Hapus Data Desa?</h2>
        <div class="content">
          <fieldset class="acc">
            <a class="acc" href="/master_desa_hapus/<?php echo e($ds->id); ?>">HAPUS</a>
            <a class="cancel" href="#">Batal</a>
          </fieldset>
        </div>
      </div>
    </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <div id="add" class="overlay">
    <div class="popup">
      <h2>Form Tambah Data</h2>
      <div class="content">
        <form id="form" action="/master_desa_tambah/<?php echo e($id); ?>" method="post">
          <?php echo e(csrf_field()); ?>

          <input type="reset" id="configreset" value="&times;" class="close" onclick="href();">
          <fieldset>
            <input placeholder="Nama Desa" type="text" autocomplete="off" name="nama" value="<?php echo e(old('nama')); ?>" tabindex="1" required oninvalid="this.setCustomValidity('Data tidak boleh kosong')" oninput="setCustomValidity('')" autofocus>
            <?php if ($errors->has('nama')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nama'); ?>
            <div class="invalid-feedback">
                <?php echo e($message); ?>

            </div>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
          </fieldset> 
          <fieldset>
            <input placeholder="Jumlah RW" type="text" autocomplete="off" name="rw" value="<?php echo e(old('rw')); ?>" tabindex="2" required oninvalid="this.setCustomValidity('Data tidak boleh kosong')" oninput="setCustomValidity('')">
            <?php if ($errors->has('rw')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('rw'); ?>
            <div class="invalid-feedback">
                <?php echo e($message); ?>

            </div>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
          </fieldset>
          <fieldset>
            <input id="bujur" placeholder="Longitude" type="text" name="bujur" value="<?php echo e(old('bujur')); ?>" required oninvalid="this.setCustomValidity('Data tidak boleh kosong')" oninput="setCustomValidity('')" readonly>
            <?php if ($errors->has('bujur')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('bujur'); ?>
            <div class="invalid-feedback">
                <?php echo e($message); ?>

            </div>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
          </fieldset>
          <fieldset>
            <input id="lintang" placeholder="Latitude" type="text" name="lintang" value="<?php echo e(old('lintang')); ?>" required oninvalid="this.setCustomValidity('Data tidak boleh kosong')" oninput="setCustomValidity('')" readonly>
            <?php if ($errors->has('lintang')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('lintang'); ?>
            <div class="invalid-feedback">
                <?php echo e($message); ?>

            </div>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
          </fieldset>
          <fieldset>
            <div onmousemove="getcenter1();" id="mapid" style="width: 100%; height: 35vh;">
              <img class="marker" src="<?php echo e(asset('gambar/marker/marker.png')); ?>" alt="">
            </div>
          </fieldset>
          <fieldset>
            <button name="submit" type="submit" id="contact-submit" data-submit="...Sending">Simpan</button>
          </fieldset>
          <fieldset>
            <a id="cancel" href="/master_desa">Cancel</a>
          </fieldset>
      </form>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
      function href() {
        window.location.href = '#';
      }
    </script>
    <script src="<?php echo e(asset('js_admin/action.js')); ?>"></script>
    <script src="<?php echo e(asset('js_admin/bundle.js')); ?>"></script>
    <script src="<?php echo e(asset('js_admin/polygon.js')); ?>"></script>
    <script src="<?php echo e(asset('js_admin/crud_map.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('super.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\TA\projek\program\master\resources\views/super/master/master_desa.blade.php ENDPATH**/ ?>