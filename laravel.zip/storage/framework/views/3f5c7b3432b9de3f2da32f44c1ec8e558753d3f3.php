<?php $__env->startSection('title','KECAMATAN'); ?>

<?php $__env->startSection('head'); ?>
  <link rel="stylesheet" href="<?php echo e(asset('style_admin/table.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('style_admin/form.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('style_admin/action.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('style_admin/alert.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('style_admin/button.css')); ?>">
  <script src="<?php echo e(asset('js_admin/nav.js')); ?>"></script>
  <link rel="stylesheet" href="https://unpkg.com/leaflet@1.6.0/dist/leaflet.css"
  integrity="sha512-xwE/Az9zrjBIphAcBb3F6JVqxf46+CDLwfLMHloNu6KEQCAWi6HcDUbeOfBIptF7tcCzusKFjFw2yuvEpDL9wQ=="
  crossorigin=""/>
  <script src="https://unpkg.com/leaflet@1.6.0/dist/leaflet.js"></script>
  <script src = "https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('copy'); ?>
oncopy='return false' oncut='return false' onpaste='return false'
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrump'); ?>
    Master Kecamatan
<?php $__env->stopSection(); ?>
<?php $__env->startSection('isi'); ?>
  <div class="isi">
    <table>
      <caption>Tabel Kecamatan</caption>
      <thead>
        <tr>
          <th scope="col">Nama Kecamatan</th>
          <th scope="col">Jumlah Desa</th>
        </tr>
      </thead>
      <?php if($count != 0): ?>
        <tbody>
          <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr id="<?php echo e($kc->id); ?>" class="table">
            <td data-label="Nama Kecamatan"><?php echo e($kc->nama); ?></td>
            <td data-label="Jumlah Desa"><?php echo e($kc->desa); ?></td>
              
              <div id="contextMenu" class="cm_<?php echo e($kc->id); ?>" style="display: none">
                <ul class="dropdown-menu" role="menu" aria-labelledby="dropdownMenu" style="display:block;position:static;margin-bottom:5px;">
                  <li class="edit">
                    <a href="#popup_e<?php echo e($kc->id); ?>">EDIT</a>
                  </li>
                  <li class="hapus">
                    <a href="#popup_h<?php echo e($kc->id); ?>">HAPUS</a>
                  </li>
                  <li class="detail">
                    <a href="/master_desa/<?php echo e($kc->id); ?>">DETAIL</a>
                  </li>
                </ul>
              </div>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      <?php else: ?>
        <tbody>
          <tr class="table">Belum ada data! Tambah sekarang...</tr>
        </tbody>
      <?php endif; ?>
    </table>
    <div class="pagination">
        <a style="color:white;" class="add" href="#add">Tambah</a>
        <?php
          // config
          $link_limit = 7;
          ?>

          <?php if($data->lastPage() > 1): ?>
              <ul>
                  <li class="<?php echo e(($data->currentPage() == 1) ? ' disabled' : ''); ?>">
                      <a href="<?php echo e($data->url(1)); ?>">First</a>
                  </li>
                  <?php for($i = 1; $i <= $data->lastPage(); $i++): ?>
                      <?php
                      $half_total_links = floor($link_limit / 2);
                      $from = $data->currentPage() - $half_total_links;
                      $to = $data->currentPage() + $half_total_links;
                      if ($data->currentPage() < $half_total_links) {
                        $to += $half_total_links - $data->currentPage();
                      }
                      if ($data->lastPage() - $data->currentPage() < $half_total_links) {
                          $from -= $half_total_links - ($data->lastPage() - $data->currentPage()) - 1;
                      }
                      ?>
                      <?php if($from < $i && $i < $to): ?>
                          <li class="<?php echo e(($data->currentPage() == $i) ? ' active' : ''); ?>">
                              <a href="<?php echo e($data->url($i)); ?>"><?php echo e($i); ?></a>
                          </li>
                      <?php endif; ?>
                  <?php endfor; ?>
                  <li class="<?php echo e(($data->currentPage() == $data->lastPage()) ? ' disabled' : ''); ?>">
                      <a href="<?php echo e($data->url($data->lastPage())); ?>">Last</a>
                  </li>
              </ul>
          <?php endif; ?>
    </div>
  </div>
  <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
    <div id="popup_e<?php echo e($kc->id); ?>" class="overlay">
      <div class="popup">
        <h2>Edit Data Kecamatan</h2>
        <div class="content">
          <form id="form" action="/master_kecamatan_ubah/<?php echo e($kc->id); ?>" method="post" enctype="multipart/form-data">
            <input type="reset" id="configreset" value="&times;" class="close" onclick="href();">
            <?php echo e(csrf_field()); ?>

            <fieldset>
              <input placeholder="Nama Kecamatan" type="text" name="nama" value="<?php echo e(old('nama') ?? $kc->nama); ?>" tabindex="1" required oninvalid="this.setCustomValidity('Data tidak boleh kosong')" oninput="setCustomValidity('')" autofocus>
              <?php if ($errors->has('nama')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nama'); ?>
              <div class="invalid-feedback">
                  <?php echo e($message); ?>

              </div>
              <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </fieldset>
            <fieldset>
              <input placeholder="Jumlah Desa" type="text" name="desa" value="<?php echo e(old('desa') ?? $kc->desa); ?>" tabindex="2" required oninvalid="this.setCustomValidity('Data tidak boleh kosong')" oninput="setCustomValidity('')">
              <?php if ($errors->has('desa')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('desa'); ?>
              <div class="invalid-feedback">
                  <?php echo e($message); ?>

              </div>
              <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </fieldset>
            <fieldset>
              <input id="json" type="file" autocomplete="off" name="batas" tabindex="3" required oninvalid="this.setCustomValidity('Data tidak boleh kosong')" oninput="setCustomValidity('')">
              <p><?php echo e($kc->batas); ?></p>
              <?php if ($errors->has('batas')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('batas'); ?>
              <div class="invalid-feedback">
                  <?php echo e($message); ?>

              </div>
              <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </fieldset>
            <fieldset>
              <input id="bujur<?php echo e($kc->id); ?>" placeholder="Longitude" type="text" name="bujur" value="<?php echo e(old('bujur') ?? $kc->bujur); ?>" required oninvalid="this.setCustomValidity('Data tidak boleh kosong')" oninput="setCustomValidity('')" readonly>
              <?php if ($errors->has('bujur')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('bujur'); ?>
              <div class="invalid-feedback">
                  <?php echo e($message); ?>

              </div>
              <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </fieldset> 
            <fieldset>
              <input id="lintang<?php echo e($kc->id); ?>" placeholder="Latitude" type="text" name="lintang" value="<?php echo e(old('lintang') ?? $kc->lintang); ?>" required oninvalid="this.setCustomValidity('Data tidak boleh kosong')" oninput="setCustomValidity('')" readonly>
              <?php if ($errors->has('lintang')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('lintang'); ?>
              <div class="invalid-feedback">
                  <?php echo e($message); ?>

              </div>
              <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </fieldset>
            <fieldset>
              <div onmousemove="getcenter2(<?php echo e($kc->id); ?>);" class="map" id="mapid<?php echo e($kc->id); ?>" style="width: 100%; height: 40vh;">
                <img class="marker" src="<?php echo e(asset('gambar/marker/marker.png')); ?>" alt="">
              </div>
            <fieldset>
            <fieldset>
              <button name="submit" type="submit" id="contact-submit" data-submit="...Sending">Submit</button>
            </fieldset>
            <fieldset>
              <a id="cancel" href="/master_kecamatan">Cancel</a>
            </fieldset>
          </form>
        </div>
      </div>
    </div>
    
    <div id="popup_h<?php echo e($kc->id); ?>" class="overlay">
      <div class="popup">
        <h2>Hapus Data Kecataman</h2>
        <div class="content">
          <p style="color: firebrick;margin-bottom: 20px">Intruksi ini akan menghapus seluruh data yang berhubungan dengan master tersebut, apakah Anda yakin untuk melanjutkan intruksi ini?</p>
          <fieldset class="acc">
            <a class="acc" href="/master_kecamatan_hapus/<?php echo e($kc->id); ?>">YA, Saya Yakin!</a>
            <a class="cancel" href="#">Batal</a>
          </fieldset>
        </div>
      </div>
    </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  
  <div id="add" class="overlay">
    <div class="popup">
      <h2>Form Tambah Data</h2>
      <div class="content">
        <form id="form" action="/master_kecamatan_tambah" method="post" enctype="multipart/form-data">
          <?php echo e(csrf_field()); ?>

          <input type="reset" id="configreset" value="&times;" class="close" onclick="href();">
          <fieldset>
            <input placeholder="Nama Kecamatan" autocomplete="off" type="text" name="nama" value="<?php echo e(old('nama')); ?>" tabindex="1" required oninvalid="this.setCustomValidity('Data tidak boleh kosong')" oninput="setCustomValidity('')" autofocus>
            <?php if ($errors->has('nama')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nama'); ?>
            <div class="invalid-feedback">
                <?php echo e($message); ?>

            </div>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
          </fieldset>
          <fieldset>
            <input placeholder="Jumlah Desa" autocomplete="off" type="text" name="desa" value="<?php echo e(old('desa')); ?>" tabindex="2" required oninvalid="this.setCustomValidity('Data tidak boleh kosong')" oninput="setCustomValidity('')">
            <?php if ($errors->has('desa')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('desa'); ?>
            <div class="invalid-feedback">
                <?php echo e($message); ?>

            </div>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
          </fieldset>
          <fieldset>
            <input id="json" type="file" autocomplete="off" name="batas" tabindex="3" required oninvalid="this.setCustomValidity('Data tidak boleh kosong')" oninput="setCustomValidity('')">
            <?php if ($errors->has('batas')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('batas'); ?>
            <div class="invalid-feedback">
                <?php echo e($message); ?>

            </div>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
          </fieldset>
          <fieldset>
            <input id="bujur" placeholder="Longitude" type="text" name="bujur" value="<?php echo e(old('bujur')); ?>" required oninvalid="this.setCustomValidity('Data tidak boleh kosong')" oninput="setCustomValidity('')" readonly>
            <?php if ($errors->has('bujur')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('bujur'); ?>
            <div class="invalid-feedback">
                <?php echo e($message); ?>

            </div>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
          </fieldset>
          <fieldset>
            <input id="lintang" placeholder="Latitude" type="text" name="lintang" value="<?php echo e(old('lintang')); ?>" required oninvalid="this.setCustomValidity('Data tidak boleh kosong')" oninput="setCustomValidity('')" readonly>
            <?php if ($errors->has('lintang')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('lintang'); ?>
            <div class="invalid-feedback">
                <?php echo e($message); ?>

            </div>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
          </fieldset>
          <fieldset>
            <div onmousemove="getcenter1();" id="mapid" style="width: 100%; height: 40vh;">
              <img class="marker" src="<?php echo e(asset('gambar/marker/marker.png')); ?>" alt="">
            </div>
          </fieldset>
          <fieldset>
            <button name="submit" type="submit" id="contact-submit" data-submit="...Sending">Simpan</button>
          </fieldset>
          <fieldset>
            <a id="cancel" href="/master_kecamatan">Cancel</a>
          </fieldset>
      </form>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
      function href() {
        window.location.href = '#';
      }
    </script>
    <script src="<?php echo e(asset('js_admin/action.js')); ?>"></script>
    <script src="<?php echo e(asset('js_admin/bundle.js')); ?>"></script>
    <script src="<?php echo e(asset('js_admin/polygon.js')); ?>"></script>
    <script src="<?php echo e(asset('js_admin/crud_map.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('super.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\TA\projek\program\master\resources\views/super/master/master_kecamatan.blade.php ENDPATH**/ ?>